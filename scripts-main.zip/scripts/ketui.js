
/* 
设置变量
ketuick='软件获取的CK'
软件下载链接 https://ningmeng6.lanzouj.com/i28PB0dix5ni

或者自己抓 随便一条查看请求头Authorization


多账号用@隔开
cron 0 0,1,2,3 * * * ketui.js
*/


const _0x1d0ef6 = _0x5983;

function _0x5983(_0x58acaa, _0x4a9318) {
    const _0x188b14 = _0x188b();
    return _0x5983 = function(_0x5983fd, _0x428217) {
        _0x5983fd = _0x5983fd - 0x8a;
        let _0x5c98d6 = _0x188b14[_0x5983fd];
        return _0x5c98d6;
    }, _0x5983(_0x58acaa, _0x4a9318);
}(function(_0xd9dbfb, _0x30e83c) {
    const _0x2ebfd6 = _0x5983,
        _0x57dce6 = _0xd9dbfb();
    while (!![]) {
        try {
            const _0x56f275 = -parseInt(_0x2ebfd6(0xc8)) / 0x1 + parseInt(_0x2ebfd6(0x8e)) / 0x2 + -parseInt(_0x2ebfd6(0x11a)) / 0x3 + parseInt(_0x2ebfd6(0x10e)) / 0x4 * (-parseInt(_0x2ebfd6(0xaa)) / 0x5) + -parseInt(_0x2ebfd6(0x125)) / 0x6 + parseInt(_0x2ebfd6(0xbe)) / 0x7 + -parseInt(_0x2ebfd6(0xc7)) / 0x8 * (-parseInt(_0x2ebfd6(0x112)) / 0x9);
            if (_0x56f275 === _0x30e83c) break;
            else _0x57dce6['push'](_0x57dce6['shift']());
        } catch (_0x1ae3dd) {
            _0x57dce6['push'](_0x57dce6['shift']());
        }
    }
}(_0x188b, 0x47374));
const $ = new Env('可推'),
    notifyFlag = 0x1,
    logDebug = 0x0;
let notifyStr = '',
    userAgent = ($[_0x1d0ef6(0xd3)]() ? process[_0x1d0ef6(0x10b)][_0x1d0ef6(0xc5)] : $[_0x1d0ef6(0x90)](_0x1d0ef6(0xc5))) || '',
    userAgentArr = ['Ketui/1.3.2 (Android 7.1.2; OPPO PCAM00)'],
    userHeader = ($['isNode']() ? process[_0x1d0ef6(0x10b)][_0x1d0ef6(0x11b)] : $['getdata'](_0x1d0ef6(0x11b))) || '',
    userHeaderArr = [],
    userIdx = 0x0,
    UAcount = 0x0,
    userStatus = [],
    spjlList = _0x1d0ef6(0xf9),
    spjlListArr = [],
    sysspjllList = '0b2b85d166a60213295115c924bb6b2a@ca8b51d7ef77dee573a05cad1e621922@1684a1fc7c27ff094629ee6951bd23c0@a361a0c65f50cf33b3169a0a089b3997@1c210e2dbfb10f0d5453e6666b44386b@4574250380d2d8de46902dd686980adc@ed77ac1e03b826f9facb1bfb086606d5@f4686aa2132bc96d004e387f8824cc12@363428318aef253c72e1064ac74d25ff@311e5c6c5646dd5a9eba001d6280b665@6a89f1d458292108b9d96d57d08c8504@230b51116fe2f2232e5725d13494f314@800c166173db6327846ffb3c13e7cc74@0d5c690cc09686b1ea7ccc3363f19242@f3a22813e369112e2be06dc7d6fb7c2e@cec18e4d7e898b18064072e5d955c57c@1600a565a3758c92eae8f05c242590c6@4a9ad04338743c4d3ffb4b67586d3a2f@e9720452df9480e79a52c33ffc37920b@405c8620b85c6c8261f049533a4bfc92,de074914f8a195362178ef207a7a5b46,f4b985deeddcc8af1cb01a6bf18db9cf',
    sysspjllListArr = [];

function _0x188b() {
    const _0x4245b7 = ['data', '1462181BVpGMe', 'mediaUrl', 'writeFileSync', 'https://api.ketui.cn/video-helper/miningTask/getGift?appId=vh&appVersion=1.3.5&configVersion=0&id=share&osType=ios&refId=kt_20048720305', 'resolve', 'toString', 'isNeedRewrite', 'ketuicookie', 'openUrl', '80FlyVSz', '193386ZnvzXL', '个Authorization，', 'errCode', '开始执行刷一刷看视频奖励', 'https://api.ketui.cn/video-helper/mining/getPower', 'cktough', 'redirect', 'getMonth', 'assign', 'getTime', 'existsSync', 'isNode', 'trim', 'getMilliseconds', 'name', 'totalSettlementAmount', '/v1/scripting/evaluate', '@chavy_boxjs_userCfgs.httpapi_timeout', 'writedata', 'random', '刷一刷视频成功获得了5金币', 'match', 'replace', 'concat', 'Cookie', 'logs', '===============准备开始分享===================', 'map', 'readFileSync', 'https://api.ketui.cn/video-helper/miningTask/getTasksCompleteNum?ids=video,draw,ksVideo,shop,share', 'startTime', 'length', 'getMinutes', 'opts', 'read', ': 服务器访问数据为空，请检查自身设备网络情况', 'setjson', '领取免费能量成功获得了2能量', 'path', 'ckjar', 'reduce', '获得了', 'then', 'statusCode', 'isMute', '运行通知\x0a\x0a', 'slice', 'send', 'https://api.ketui.cn/video-helper/miningTask/getGift?appId=vh&appVersion=1.3.5&configVersion=0&id=ksVideo&osType=ios&refId=', '83b2b895a5347de47f569e4d27842c975a62b3d296@83b2bc453754726317e3f048aab5e935247003a4f4', 'catch', '===============准备开始充电===================', 'https://api.ketui.cn/video-helper/miningSign/', 'media-url', 'timeout', 'http', 'get', 'push', 'initGotEnv', 'setdata', 'https://api.ketui.cn/video-helper/miningTask/getGift?id=video&type=taskList&refId=', 'round', 'isQuanX', 'parse', 'getval', ', 错误!', '签到成功', 'env', 'logSeparator', '开始执行获取视频奖励', '4QKyGLb', 'list', 'url', '*/*', '566118SbccAH', 'split', 'done', ', 结束! 🕛 ', 'msg', 'setval', 'isSurge', 'exec', '533601TYaJaS', 'ketuick', 'method', 'join', 'logErr', 'wait', ' API请求失败，请检查网路重试', 'test', 'open-url', 'getSeconds', 'post', '1072344VxvSgP', '未找到userAgent', 'getHours', 'ck失效', '===============准备开始智能检测未完成任务===================', 'log', 'https://api.ketui.cn/video-helper/mining/addPower?power=24', 'headers', 'application/x-www-form-urlencoded', 'string', '311006sGYaqB', ': 未知错误', 'getdata', 'valueForKey', '加油成功', 'stringify', 'Function ', 'getScript', '@chavy_boxjs_userCfgs.httpapi', 'CookieJar', 'fetch', '===============准备开始检查个人累计金币===================', 'floor', '&type=taskList', 'call', 'lodash_set', '==============📣系统通知📣==============', 'object', 'POST', 'cookieJar', 'getFullYear', 'errMsg', 'loaddata', 'cwd', 'getDate', 'substr', 'lodash_get', 'isArray', '758645qXDkqA', 'Content-Type', '任务已全部完成，无需执行', 'got', ', 开始!', '.$1', 'isLoon', 'cron', 'toStr', 'body', 'https://api.ketui.cn/video-helper/withdraw/withdraw?payType=wechat', 'time', 'setCookieSync', 'ksVideofalse', 'box.dat', 'undefined', 'stack', 'dataFile', 'isCompleted'];
    _0x188b = function() {
        return _0x4245b7;
    };
    return _0x188b();
}!(async () => {
    const _0x4c1ad3 = _0x1d0ef6;
    if (typeof $request !== _0x4c1ad3(0xb9)) await GetRewrite();
    else {
        if (!await checkEnv()) return;
        await initAccountInfo(), await RunMultiUser();
    }
})()[_0x1d0ef6(0xfa)](_0x544296 => $[_0x1d0ef6(0x11e)](_0x544296))['finally'](() => $[_0x1d0ef6(0x114)]());
async function showmsg() {
    const _0x36d7fd = _0x1d0ef6;
    notifyBody = $[_0x36d7fd(0xd6)] + _0x36d7fd(0xf5) + notifyStr, notifyFlag != 0x1 && console['log'](notifyBody), notifyFlag == 0x1 && $[_0x36d7fd(0x116)](notifyBody);
}
async function checkEnv() {
    const _0x9064ab = _0x1d0ef6;
    if (userHeader) userHeaderArr = userHeader[_0x9064ab(0x113)]('@');
    else return console[_0x9064ab(0x12a)]('未找到ketuick\x0a点击刷一刷 看完一个视频 去https://api.ketui.cn/video-helper/miningTask/getGift?appId=vh&appVersion=1.3.5&configVersion=0&id=ksVideo&osType=ios找Authorization复制到变量  ketuick，找cookie复制到变量   ketuicookie'), ![];
    if (userHeaderArr[_0x9064ab(0xe7)] == 0x0) return console[_0x9064ab(0x12a)]('未找到有效的ketuick\x0a点击刷一刷 看完一个视频 去https://api.ketui.cn/video-helper/miningTask/getGift?appId=vh&appVersion=1.3.5&configVersion=0&id=ksVideo&osType=ios找Authorization复制到变量  ketuick，找cookie复制到变量   ketuicookie'), ![];
    if (userAgent) userAgentArr = userAgent[_0x9064ab(0x113)]('@');
    
    return UAcount = userAgentArr[_0x9064ab(0xe7)], console[_0x9064ab(0x12a)]('共找到' + userHeaderArr[_0x9064ab(0xe7)] + _0x9064ab(0xc9) + UAcount + '个cookie'), !![];
}
async function initAccountInfo() {
    const _0x43fc54 = _0x1d0ef6;
    for (userIdx = 0x0; userIdx < userHeaderArr[_0x43fc54(0xe7)]; userIdx++) {
        userStatus[_0x43fc54(0x101)](!![]);
    }
}
async function RunMultiUser() {
    const _0x1a08c8 = _0x1d0ef6;
    for (userIdx = 0x0; userIdx < userHeaderArr['length']; userIdx++) {
        console[_0x1a08c8(0x12a)]('===============准备开始每日签到==================='), await qd(), await $['wait'](0x3e8), console[_0x1a08c8(0x12a)](_0x1a08c8(0x129)), await qdd(), await $[_0x1a08c8(0x11f)](0x3e8), await kisll(), await $[_0x1a08c8(0x11f)](0x3e8), console['log']('===============准备开始领取每日免费能量==================='), await mfnl(), await $[_0x1a08c8(0x11f)](0x3e8), console[_0x1a08c8(0x12a)](_0x1a08c8(0xe2)), await share(), await $[_0x1a08c8(0x11f)](0x3e8), console[_0x1a08c8(0x12a)](_0x1a08c8(0xfb)), await jiayou(), await $[_0x1a08c8(0x11f)](0x3e8), console[_0x1a08c8(0x12a)](_0x1a08c8(0x99)), await info(), await $[_0x1a08c8(0x11f)](0x3e8);
    }
}
async function tt(_0x4bf334) {
    const _0x1236d7 = _0x1d0ef6;
    _0x4bf334 == 'videofalse' && (console[_0x1236d7(0x12a)](_0x1236d7(0x10d)), await ExcitationAd(), await $[_0x1236d7(0x11f)](0x3e8));
    if (_0x4bf334 == _0x1236d7(0xb7)) console[_0x1236d7(0x12a)](_0x1236d7(0xcb)), await sys(), await $['wait'](0x3e8);
    else {
        console[_0x1236d7(0x12a)](_0x1236d7(0xac));
        return;
    }
}
async function kisll() {
    const _0x2e4822 = _0x1d0ef6;
    for (let _0x32d16e = 0x0; _0x32d16e < carray[_0x2e4822(0xe7)]; _0x32d16e++) {
        await tt(carray[_0x32d16e]);
    }
}
async function qdd() {
    return new Promise(_0x4d13eb => {
        const _0x547c3c = _0x5983;
        let _0x3cda30 = {
            'url': _0x547c3c(0xe5),
            'headers': {
                'appId': 'vh',
                'Authorization': userHeaderArr[userIdx]
            }
        };
        $[_0x547c3c(0x100)](_0x3cda30, async (_0x2777db, _0x117e4d, _0x3dfee7) => {
            const _0x512963 = _0x547c3c;
            try {
                if (_0x2777db) console[_0x512963(0x12a)]('' + JSON[_0x512963(0x93)](_0x2777db)), console[_0x512963(0x12a)]($[_0x512963(0xd6)] + _0x512963(0x120));
                else {
                    _0x3dfee7 = JSON[_0x512963(0x107)](_0x3dfee7);
                    let _0x709913 = _0x3dfee7[_0x512963(0xbd)][_0x512963(0x10f)],
                        _0x46d426 = _0x709913[_0x512963(0xe3)](_0x501dc6 => {
                            const _0x493d22 = _0x512963;
                            return _0x501dc6['taskId'] + _0x501dc6[_0x493d22(0xbc)];
                        });
                    carray = _0x46d426;
                }
            } catch (_0x2247ed) {
                $[_0x512963(0x11e)](_0x2247ed, _0x117e4d);
            } finally {
                _0x4d13eb(_0x3dfee7);
            }
        });
    });
}
async function share() {
    return new Promise(_0x5a8d2c => {
        const _0x288be7 = _0x5983,
            _0x3f467d = Math[_0x288be7(0x105)](Math[_0x288be7(0xdb)]() * 0x5 + 0x5 + 0x5 + 0x64 + 0x96 + 0xc8 + 0x64 + 0xc8 + 0x2710);
        let _0x4cbd92 = {
            'url': _0x288be7(0xc1) + _0x3f467d + _0x288be7(0x9b),
            'headers': {
                'appId': 'vh',
                'Authorization': userHeaderArr[userIdx]
            }
        };
        $[_0x288be7(0x100)](_0x4cbd92, async (_0x1b824d, _0x2a1da7, _0x147101) => {
            const _0x178a4f = _0x288be7;
            try {
                _0x1b824d ? (console[_0x178a4f(0x12a)]('' + JSON['stringify'](_0x1b824d)), console[_0x178a4f(0x12a)]($['name'] + _0x178a4f(0x120))) : (_0x147101 = JSON[_0x178a4f(0x107)](_0x147101), _0x147101['errCode'] == 0x0 ? console[_0x178a4f(0x12a)](_0x147101[_0x178a4f(0xa3)]) : console[_0x178a4f(0x12a)](_0x147101));
            } catch (_0x1105fd) {
                $[_0x178a4f(0x11e)](_0x1105fd, _0x2a1da7);
            } finally {
                _0x5a8d2c(_0x147101);
            }
        });
    });
}
async function tx() {
    return new Promise(_0x2bedf1 => {
        const _0x35296d = _0x5983;
        let _0x80567 = {
            'url': _0x35296d(0xb4),
            'headers': {
                'appId': 'vh',
                'Authorization': userHeaderArr[userIdx],
                'Cookie': userAgentArr[userIdx % UAcount],
                'Content-Type': 'application/json'
            },
            'body': '{\"withdrawAmount\":\"1.3\"}'
        };
        $[_0x35296d(0x124)](_0x80567, async (_0x3d5033, _0x43f585, _0x400dac) => {
            const _0x174ade = _0x35296d;
            try {
                if (_0x3d5033) console['log']('' + JSON[_0x174ade(0x93)](_0x3d5033)), console['log']($[_0x174ade(0xd6)] + ' API请求失败，请检查网路重试');
                else {
                    _0x400dac = JSON[_0x174ade(0x107)](_0x400dac);
                    if (_0x400dac[_0x174ade(0xca)] == 0x0) {}
                    _0x400dac[_0x174ade(0xca)] == 0x270c ? console[_0x174ade(0x12a)]('无法提现，还未进行实名认证') : console[_0x174ade(0x12a)](_0x400dac);
                }
            } catch (_0x29f620) {
                $[_0x174ade(0x11e)](_0x29f620, _0x43f585);
            } finally {
                _0x2bedf1(_0x400dac);
            }
        });
    });
}
async function info() {
    return new Promise(_0xa7cf0f => {
        let _0x219685 = {
            'url': 'https://api.ketui.cn/video-helper/mining/getMiningInfo',
            'headers': {
                'appId': 'vh',
                'Authorization': userHeaderArr[userIdx]
            }
        };
        $['get'](_0x219685, async (_0x221a6b, _0x516a50, _0x319a6e) => {
            const _0x314b0a = _0x5983;
            try {
                _0x221a6b ? (console[_0x314b0a(0x12a)]('' + JSON['stringify'](_0x221a6b)), console[_0x314b0a(0x12a)]($[_0x314b0a(0xd6)] + _0x314b0a(0x120))) : (_0x319a6e = JSON[_0x314b0a(0x107)](_0x319a6e), _0x319a6e[_0x314b0a(0xca)] == 0x0 ? console[_0x314b0a(0x12a)]('当前已累计金币' + _0x319a6e['data'][_0x314b0a(0xd7)]) : console[_0x314b0a(0x12a)](_0x314b0a(0x128)));
            } catch (_0x19121d) {
                $['logErr'](_0x19121d, _0x516a50);
            } finally {
                _0xa7cf0f(_0x319a6e);
            }
        });
    });
}
async function qd() {
    return new Promise(_0x2945dd => {
        const _0x263e25 = _0x5983;
        let _0x1251ae = {
            'url': _0x263e25(0xfc),
            'headers': {
                'appId': 'vh',
                'Authorization': userHeaderArr[userIdx]
            }
        };
        $[_0x263e25(0x100)](_0x1251ae, async (_0x501ecc, _0xdbc865, _0x2bb8f4) => {
            const _0x47fd02 = _0x263e25;
            try {
                _0x501ecc ? (console[_0x47fd02(0x12a)]('' + JSON[_0x47fd02(0x93)](_0x501ecc)), console[_0x47fd02(0x12a)]($[_0x47fd02(0xd6)] + _0x47fd02(0x120))) : (_0x2bb8f4 = JSON[_0x47fd02(0x107)](_0x2bb8f4), _0x2bb8f4['errCode'] == 0x0 ? console['log'](_0x47fd02(0x10a) + _0x47fd02(0xf1) + _0x2bb8f4[_0x47fd02(0xbd)]['rewardPower'] + '能量') : console[_0x47fd02(0x12a)](_0x2bb8f4));
            } catch (_0x4037ab) {
                $['logErr'](_0x4037ab, _0xdbc865);
            } finally {
                _0x2945dd(_0x2bb8f4);
            }
        });
    });
}
async function jiayou() {
    return new Promise(_0x5941ba => {
        const _0x243c5d = _0x5983;
        let _0x145c3d = {
            'url': _0x243c5d(0x8a),
            'headers': {
                'appId': 'vh',
                'Authorization': userHeaderArr[userIdx]
            }
        };
        $[_0x243c5d(0x100)](_0x145c3d, async (_0x284cca, _0x3cf9b2, _0x1e008e) => {
            const _0x22c4ce = _0x243c5d;
            try {
                _0x284cca ? (console[_0x22c4ce(0x12a)]('' + JSON[_0x22c4ce(0x93)](_0x284cca)), console['log']($['name'] + _0x22c4ce(0x120))) : (_0x1e008e = JSON[_0x22c4ce(0x107)](_0x1e008e), _0x1e008e['errCode'] == 0x0 ? console[_0x22c4ce(0x12a)](_0x22c4ce(0x92)) : console[_0x22c4ce(0x12a)]('能量不足，无法加油'));
            } catch (_0x24a8bc) {
                $[_0x22c4ce(0x11e)](_0x24a8bc, _0x3cf9b2);
            } finally {
                _0x5941ba(_0x1e008e);
            }
        });
    });
}
async function mfnl() {
    return new Promise(_0x5e0dcc => {
        const _0x2f7370 = _0x5983;
        let _0x114659 = {
            'url': _0x2f7370(0xcc),
            'headers': {
                'appId': 'vh',
                'Authorization': userHeaderArr[userIdx]
            }
        };
        $[_0x2f7370(0x100)](_0x114659, async (_0xa1c373, _0x2924a9, _0x39acf4) => {
            const _0x4ea081 = _0x2f7370;
            try {
                _0xa1c373 ? (console[_0x4ea081(0x12a)]('' + JSON[_0x4ea081(0x93)](_0xa1c373)), console[_0x4ea081(0x12a)]($[_0x4ea081(0xd6)] + _0x4ea081(0x120))) : (_0x39acf4 = JSON['parse'](_0x39acf4), _0x39acf4[_0x4ea081(0xca)] == 0x0 && console[_0x4ea081(0x12a)](_0x4ea081(0xed)), _0x39acf4[_0x4ea081(0xca)] == 0x1962 ? console['log'](_0x39acf4[_0x4ea081(0xa3)]) : console[_0x4ea081(0x12a)](_0x39acf4));
            } catch (_0x11a941) {
                $[_0x4ea081(0x11e)](_0x11a941, _0x2924a9);
            } finally {
                _0x5e0dcc(_0x39acf4);
            }
        });
    });
}
async function ExcitationAd() {
    const _0xfc5c1b = _0x1d0ef6;
    spjlListArr = spjlList['split']('@');
    for (let _0x58f440 = 0x0; _0x58f440 < spjlListArr[_0xfc5c1b(0xe7)]; _0x58f440++) {
        await tc(spjlListArr[_0x58f440]), await $[_0xfc5c1b(0x11f)](0x2710);
    }
}
async function tc(_0x24671c) {
    return new Promise(_0x2ca5cc => {
        const _0x402139 = _0x5983;
        let _0xfe4f66 = {
            'url': _0x402139(0x104) + _0x24671c,
            'headers': {
                'appId': 'vh',
                'Authorization': userHeaderArr[userIdx]
            }
        };
        $[_0x402139(0x100)](_0xfe4f66, async (_0x40013a, _0x1431f7, _0x46e616) => {
            const _0x368879 = _0x402139;
            try {
                _0x40013a ? (console[_0x368879(0x12a)]('' + JSON['stringify'](_0x40013a)), console[_0x368879(0x12a)]($[_0x368879(0xd6)] + _0x368879(0x120))) : (_0x46e616 = JSON[_0x368879(0x107)](_0x46e616), _0x46e616[_0x368879(0xca)] == 0x0 ? console[_0x368879(0x12a)]('每日看视频奖励成功获得了2能量') : console[_0x368879(0x12a)](_0x46e616));
            } catch (_0xabdd42) {
                $[_0x368879(0x11e)](_0xabdd42, _0x1431f7);
            } finally {
                _0x2ca5cc(_0x46e616);
            }
        });
    });
}
async function sys() {
    const _0x2b165c = _0x1d0ef6;
    sysspjllListArr = sysspjllList['split']('@');
    for (let _0x55cead = 0x0; _0x55cead < sysspjllListArr[_0x2b165c(0xe7)]; _0x55cead++) {
        await syssp(sysspjllListArr[_0x55cead]), await $['wait'](0x1770);
    }
}
async function syssp(_0x42b40f) {
    return new Promise(_0x1f1e5f => {
        const _0x2322ba = _0x5983;
        let _0x54bbd1 = {
            'url': _0x2322ba(0xf8) + _0x42b40f + _0x2322ba(0x9b),
            'headers': {
                'appId': 'vh',
                'Authorization': userHeaderArr[userIdx],
                'Cookie': userAgentArr[userIdx % UAcount]
            }
        };
        $[_0x2322ba(0x100)](_0x54bbd1, async (_0x5a6a0c, _0x211303, _0x1172ec) => {
            const _0x7163a3 = _0x2322ba;
            try {
                _0x5a6a0c ? (console[_0x7163a3(0x12a)]('' + JSON[_0x7163a3(0x93)](_0x5a6a0c)), console['log']($['name'] + _0x7163a3(0x120))) : (_0x1172ec = JSON[_0x7163a3(0x107)](_0x1172ec), _0x1172ec['errCode'] == 0x0 ? console[_0x7163a3(0x12a)](_0x7163a3(0xdc)) : console[_0x7163a3(0x12a)](_0x1172ec));
            } catch (_0x4cb0cb) {
                $[_0x7163a3(0x11e)](_0x4cb0cb, _0x211303);
            } finally {
                _0x1f1e5f(_0x1172ec);
            }
        });
    });
}

function safeGet(_0x2d5df5, _0x3251a3) {
    const _0x2082d7 = _0x1d0ef6;
    try {
        if (typeof JSON['parse'](_0x2d5df5) == 'object') return !![];
        else console['log'](_0x2082d7(0x94) + _0x3251a3 + _0x2082d7(0x8f)), console[_0x2082d7(0x12a)](_0x2d5df5);
    } catch (_0x34683c) {
        return console[_0x2082d7(0x12a)](_0x34683c), console['log']('Function ' + _0x3251a3 + _0x2082d7(0xeb)), ![];
    }
}

function printCaller() {
    const _0x26dffe = _0x1d0ef6;
    return new Error()[_0x26dffe(0xba)][_0x26dffe(0x113)]('\x0a')[0x2][_0x26dffe(0xd4)]()['split'](' ')[0x1];
}

function getMin(_0xa6f87, _0x20fc04) {
    return _0xa6f87 < _0x20fc04 ? _0xa6f87 : _0x20fc04;
}

function getMax(_0x320ff4, _0x39e4fb) {
    return _0x320ff4 < _0x39e4fb ? _0x39e4fb : _0x320ff4;
}

function Env(_0x3b9c08, _0x519497) {
    const _0x12d81a = _0x1d0ef6;
    class _0x1f333d {
        constructor(_0x2a9d1c) {
            this['env'] = _0x2a9d1c;
        } [_0x12d81a(0xf7)](_0x26d705, _0x1bbacb = 'GET') {
            const _0x2367d8 = _0x12d81a;
            _0x26d705 = _0x2367d8(0x8d) == typeof _0x26d705 ? {
                'url': _0x26d705
            } : _0x26d705;
            let _0x5136c8 = this[_0x2367d8(0x100)];
            return _0x2367d8(0xa0) === _0x1bbacb && (_0x5136c8 = this['post']), new Promise((_0x1fdfa0, _0x3f90e0) => {
                _0x5136c8['call'](this, _0x26d705, (_0x549427, _0x3b0022, _0x4eae2b) => {
                    _0x549427 ? _0x3f90e0(_0x549427) : _0x1fdfa0(_0x3b0022);
                });
            });
        } ['get'](_0x2df095) {
            const _0x253040 = _0x12d81a;
            return this[_0x253040(0xf7)][_0x253040(0x9c)](this[_0x253040(0x10b)], _0x2df095);
        } ['post'](_0x4e8331) {
            const _0x392b6e = _0x12d81a;
            return this[_0x392b6e(0xf7)][_0x392b6e(0x9c)](this['env'], _0x4e8331, _0x392b6e(0xa0));
        }
    }
    return new class {
        constructor(_0x5b453f, _0x410807) {
            const _0x505578 = _0x12d81a;
            this[_0x505578(0xd6)] = _0x5b453f, this[_0x505578(0xff)] = new _0x1f333d(this), this[_0x505578(0xbd)] = null, this[_0x505578(0xbb)] = _0x505578(0xb8), this['logs'] = [], this[_0x505578(0xf4)] = !0x1, this[_0x505578(0xc4)] = !0x1, this[_0x505578(0x10c)] = '\x0a', this['startTime'] = new Date()[_0x505578(0xd1)](), Object['assign'](this, _0x410807), this[_0x505578(0x12a)]('', '🔔' + this[_0x505578(0xd6)] + _0x505578(0xae));
        } [_0x12d81a(0xd3)]() {
            const _0x1c22c8 = _0x12d81a;
            return _0x1c22c8(0xb9) != typeof module && !!module['exports'];
        } ['isQuanX']() {
            return 'undefined' != typeof $task;
        } [_0x12d81a(0x118)]() {
            return 'undefined' != typeof $httpClient && 'undefined' == typeof $loon;
        } [_0x12d81a(0xb0)]() {
            return 'undefined' != typeof $loon;
        } ['toObj'](_0x10b836, _0x1c510b = null) {
            try {
                return JSON['parse'](_0x10b836);
            } catch {
                return _0x1c510b;
            }
        } [_0x12d81a(0xb2)](_0x3723a2, _0x21dc7d = null) {
            const _0x4953a9 = _0x12d81a;
            try {
                return JSON[_0x4953a9(0x93)](_0x3723a2);
            } catch {
                return _0x21dc7d;
            }
        } ['getjson'](_0x1c7287, _0x12317a) {
            const _0x45d435 = _0x12d81a;
            let _0x1a0bf2 = _0x12317a;
            const _0x208108 = this[_0x45d435(0x90)](_0x1c7287);
            if (_0x208108) try {
                _0x1a0bf2 = JSON[_0x45d435(0x107)](this[_0x45d435(0x90)](_0x1c7287));
            } catch {}
            return _0x1a0bf2;
        } [_0x12d81a(0xec)](_0x321be9, _0xcd360f) {
            const _0x3bb41b = _0x12d81a;
            try {
                return this[_0x3bb41b(0x103)](JSON['stringify'](_0x321be9), _0xcd360f);
            } catch {
                return !0x1;
            }
        } [_0x12d81a(0x95)](_0x29ef27) {
            return new Promise(_0x4e1e8c => {
                this['get']({
                    'url': _0x29ef27
                }, (_0x891c3d, _0x5765ea, _0xe26636) => _0x4e1e8c(_0xe26636));
            });
        } ['runScript'](_0x382c1f, _0x252b0a) {
            const _0x4b0b82 = _0x12d81a;
            return new Promise(_0x5d7e1c => {
                const _0x3f9e20 = _0x5983;
                let _0x2675b3 = this[_0x3f9e20(0x90)](_0x3f9e20(0x96));
                _0x2675b3 = _0x2675b3 ? _0x2675b3[_0x3f9e20(0xde)](/\n/g, '')[_0x3f9e20(0xd4)]() : _0x2675b3;
                let _0x83850b = this['getdata'](_0x3f9e20(0xd9));
                _0x83850b = _0x83850b ? 0x1 * _0x83850b : 0x14, _0x83850b = _0x252b0a && _0x252b0a['timeout'] ? _0x252b0a[_0x3f9e20(0xfe)] : _0x83850b;
                const [_0x35fec0, _0x566d21] = _0x2675b3[_0x3f9e20(0x113)]('@'), _0x296a67 = {
                    'url': 'http://' + _0x566d21 + _0x3f9e20(0xd8),
                    'body': {
                        'script_text': _0x382c1f,
                        'mock_type': _0x3f9e20(0xb1),
                        'timeout': _0x83850b
                    },
                    'headers': {
                        'X-Key': _0x35fec0,
                        'Accept': _0x3f9e20(0x111)
                    }
                };
                this['post'](_0x296a67, (_0x89b06d, _0x163928, _0x3612e8) => _0x5d7e1c(_0x3612e8));
            })[_0x4b0b82(0xfa)](_0x4dbb17 => this['logErr'](_0x4dbb17));
        } [_0x12d81a(0xa4)]() {
            const _0x280652 = _0x12d81a;
            if (!this[_0x280652(0xd3)]()) return {}; {
                this['fs'] = this['fs'] ? this['fs'] : require('fs'), this[_0x280652(0xee)] = this[_0x280652(0xee)] ? this[_0x280652(0xee)] : require(_0x280652(0xee));
                const _0xa3f33c = this[_0x280652(0xee)]['resolve'](this['dataFile']),
                    _0x218b99 = this[_0x280652(0xee)][_0x280652(0xc2)](process[_0x280652(0xa5)](), this['dataFile']),
                    _0x175a8f = this['fs'][_0x280652(0xd2)](_0xa3f33c),
                    _0x5164c5 = !_0x175a8f && this['fs'][_0x280652(0xd2)](_0x218b99);
                if (!_0x175a8f && !_0x5164c5) return {}; {
                    const _0x10a902 = _0x175a8f ? _0xa3f33c : _0x218b99;
                    try {
                        return JSON[_0x280652(0x107)](this['fs'][_0x280652(0xe4)](_0x10a902));
                    } catch (_0x4bbe75) {
                        return {};
                    }
                }
            }
        } [_0x12d81a(0xda)]() {
            const _0x11fb52 = _0x12d81a;
            if (this[_0x11fb52(0xd3)]()) {
                this['fs'] = this['fs'] ? this['fs'] : require('fs'), this[_0x11fb52(0xee)] = this['path'] ? this[_0x11fb52(0xee)] : require('path');
                const _0x332ac2 = this[_0x11fb52(0xee)][_0x11fb52(0xc2)](this[_0x11fb52(0xbb)]),
                    _0x367a0e = this[_0x11fb52(0xee)]['resolve'](process[_0x11fb52(0xa5)](), this[_0x11fb52(0xbb)]),
                    _0x27c5fd = this['fs']['existsSync'](_0x332ac2),
                    _0xbb4abf = !_0x27c5fd && this['fs'][_0x11fb52(0xd2)](_0x367a0e),
                    _0x30ff7d = JSON[_0x11fb52(0x93)](this[_0x11fb52(0xbd)]);
                _0x27c5fd ? this['fs'][_0x11fb52(0xc0)](_0x332ac2, _0x30ff7d) : _0xbb4abf ? this['fs'][_0x11fb52(0xc0)](_0x367a0e, _0x30ff7d) : this['fs'][_0x11fb52(0xc0)](_0x332ac2, _0x30ff7d);
            }
        } [_0x12d81a(0xa8)](_0x271d55, _0x1b16c2, _0x38bf5a) {
            const _0x40d3bc = _0x12d81a,
                _0x420bdd = _0x1b16c2['replace'](/\[(\d+)\]/g, _0x40d3bc(0xaf))[_0x40d3bc(0x113)]('.');
            let _0x5e48d2 = _0x271d55;
            for (const _0x5a6c4d of _0x420bdd)
                if (_0x5e48d2 = Object(_0x5e48d2)[_0x5a6c4d], void 0x0 === _0x5e48d2) return _0x38bf5a;
            return _0x5e48d2;
        } [_0x12d81a(0x9d)](_0x41adc1, _0x5482bd, _0x13ee68) {
            const _0x2cf6a1 = _0x12d81a;
            return Object(_0x41adc1) !== _0x41adc1 ? _0x41adc1 : (Array[_0x2cf6a1(0xa9)](_0x5482bd) || (_0x5482bd = _0x5482bd[_0x2cf6a1(0xc3)]()[_0x2cf6a1(0xdd)](/[^.[\]]+/g) || []), _0x5482bd[_0x2cf6a1(0xf6)](0x0, -0x1)[_0x2cf6a1(0xf0)]((_0x181d05, _0x38a398, _0x283c86) => Object(_0x181d05[_0x38a398]) === _0x181d05[_0x38a398] ? _0x181d05[_0x38a398] : _0x181d05[_0x38a398] = Math['abs'](_0x5482bd[_0x283c86 + 0x1]) >> 0x0 == +_0x5482bd[_0x283c86 + 0x1] ? [] : {}, _0x41adc1)[_0x5482bd[_0x5482bd[_0x2cf6a1(0xe7)] - 0x1]] = _0x13ee68, _0x41adc1);
        } [_0x12d81a(0x90)](_0x19c8c2) {
            const _0x4824fb = _0x12d81a;
            let _0x4cae78 = this[_0x4824fb(0x108)](_0x19c8c2);
            if (/^@/ ['test'](_0x19c8c2)) {
                const [, _0x40eaea, _0x2066f8] = /^@(.*?)\.(.*?)$/ [_0x4824fb(0x119)](_0x19c8c2), _0x3bfdcd = _0x40eaea ? this[_0x4824fb(0x108)](_0x40eaea) : '';
                if (_0x3bfdcd) try {
                    const _0x38849b = JSON[_0x4824fb(0x107)](_0x3bfdcd);
                    _0x4cae78 = _0x38849b ? this[_0x4824fb(0xa8)](_0x38849b, _0x2066f8, '') : _0x4cae78;
                } catch (_0x513caf) {
                    _0x4cae78 = '';
                }
            }
            return _0x4cae78;
        } [_0x12d81a(0x103)](_0x237b2f, _0x2f8200) {
            const _0x85e2e6 = _0x12d81a;
            let _0x41bdb3 = !0x1;
            if (/^@/ [_0x85e2e6(0x121)](_0x2f8200)) {
                const [, _0x40787e, _0x30b24d] = /^@(.*?)\.(.*?)$/ [_0x85e2e6(0x119)](_0x2f8200), _0x187d7f = this[_0x85e2e6(0x108)](_0x40787e), _0x3c30cc = _0x40787e ? 'null' === _0x187d7f ? null : _0x187d7f || '{}' : '{}';
                try {
                    const _0x1f319d = JSON['parse'](_0x3c30cc);
                    this['lodash_set'](_0x1f319d, _0x30b24d, _0x237b2f), _0x41bdb3 = this['setval'](JSON[_0x85e2e6(0x93)](_0x1f319d), _0x40787e);
                } catch (_0x448fc2) {
                    const _0x39f57d = {};
                    this[_0x85e2e6(0x9d)](_0x39f57d, _0x30b24d, _0x237b2f), _0x41bdb3 = this[_0x85e2e6(0x117)](JSON[_0x85e2e6(0x93)](_0x39f57d), _0x40787e);
                }
            } else _0x41bdb3 = this[_0x85e2e6(0x117)](_0x237b2f, _0x2f8200);
            return _0x41bdb3;
        } [_0x12d81a(0x108)](_0x5c7589) {
            const _0x49e321 = _0x12d81a;
            return this[_0x49e321(0x118)]() || this[_0x49e321(0xb0)]() ? $persistentStore[_0x49e321(0xea)](_0x5c7589) : this['isQuanX']() ? $prefs[_0x49e321(0x91)](_0x5c7589) : this[_0x49e321(0xd3)]() ? (this[_0x49e321(0xbd)] = this[_0x49e321(0xa4)](), this[_0x49e321(0xbd)][_0x5c7589]) : this[_0x49e321(0xbd)] && this['data'][_0x5c7589] || null;
        } ['setval'](_0xe0fb02, _0x5d11d3) {
            const _0x223889 = _0x12d81a;
            return this[_0x223889(0x118)]() || this[_0x223889(0xb0)]() ? $persistentStore['write'](_0xe0fb02, _0x5d11d3) : this[_0x223889(0x106)]() ? $prefs['setValueForKey'](_0xe0fb02, _0x5d11d3) : this[_0x223889(0xd3)]() ? (this[_0x223889(0xbd)] = this['loaddata'](), this[_0x223889(0xbd)][_0x5d11d3] = _0xe0fb02, this['writedata'](), !0x0) : this[_0x223889(0xbd)] && this[_0x223889(0xbd)][_0x5d11d3] || null;
        } ['initGotEnv'](_0x422c55) {
            const _0x35defa = _0x12d81a;
            this['got'] = this[_0x35defa(0xad)] ? this['got'] : require('got'), this[_0x35defa(0xcd)] = this['cktough'] ? this['cktough'] : require('tough-cookie'), this['ckjar'] = this[_0x35defa(0xef)] ? this['ckjar'] : new this[(_0x35defa(0xcd))][(_0x35defa(0x97))](), _0x422c55 && (_0x422c55[_0x35defa(0x8b)] = _0x422c55['headers'] ? _0x422c55[_0x35defa(0x8b)] : {}, void 0x0 === _0x422c55[_0x35defa(0x8b)]['Cookie'] && void 0x0 === _0x422c55[_0x35defa(0xa1)] && (_0x422c55['cookieJar'] = this[_0x35defa(0xef)]));
        } [_0x12d81a(0x100)](_0x1a7f65, _0xeed8e5 = () => {}) {
            const _0x45507d = _0x12d81a;
            _0x1a7f65[_0x45507d(0x8b)] && (delete _0x1a7f65[_0x45507d(0x8b)][_0x45507d(0xab)], delete _0x1a7f65['headers']['Content-Length']), this['isSurge']() || this['isLoon']() ? (this['isSurge']() && this[_0x45507d(0xc4)] && (_0x1a7f65[_0x45507d(0x8b)] = _0x1a7f65[_0x45507d(0x8b)] || {}, Object[_0x45507d(0xd0)](_0x1a7f65[_0x45507d(0x8b)], {
                'X-Surge-Skip-Scripting': !0x1
            })), $httpClient['get'](_0x1a7f65, (_0x12464c, _0xaef971, _0x4ba07d) => {
                const _0x562757 = _0x45507d;
                !_0x12464c && _0xaef971 && (_0xaef971[_0x562757(0xb3)] = _0x4ba07d, _0xaef971[_0x562757(0xf3)] = _0xaef971['status']), _0xeed8e5(_0x12464c, _0xaef971, _0x4ba07d);
            })) : this[_0x45507d(0x106)]() ? (this['isNeedRewrite'] && (_0x1a7f65['opts'] = _0x1a7f65[_0x45507d(0xe9)] || {}, Object[_0x45507d(0xd0)](_0x1a7f65[_0x45507d(0xe9)], {
                'hints': !0x1
            })), $task[_0x45507d(0x98)](_0x1a7f65)[_0x45507d(0xf2)](_0x349571 => {
                const {
                    statusCode: _0x1448e7,
                    statusCode: _0x20d2ee,
                    headers: _0x36fe9d,
                    body: _0x808566
                } = _0x349571;
                _0xeed8e5(null, {
                    'status': _0x1448e7,
                    'statusCode': _0x20d2ee,
                    'headers': _0x36fe9d,
                    'body': _0x808566
                }, _0x808566);
            }, _0x1d70af => _0xeed8e5(_0x1d70af))) : this[_0x45507d(0xd3)]() && (this[_0x45507d(0x102)](_0x1a7f65), this['got'](_0x1a7f65)['on'](_0x45507d(0xce), (_0x53731b, _0x291772) => {
                const _0xe2b751 = _0x45507d;
                try {
                    if (_0x53731b[_0xe2b751(0x8b)]['set-cookie']) {
                        const _0x55ccda = _0x53731b[_0xe2b751(0x8b)]['set-cookie'][_0xe2b751(0xe3)](this[_0xe2b751(0xcd)][_0xe2b751(0xe0)][_0xe2b751(0x107)])[_0xe2b751(0xc3)]();
                        this[_0xe2b751(0xef)][_0xe2b751(0xb6)](_0x55ccda, null), _0x291772['cookieJar'] = this[_0xe2b751(0xef)];
                    }
                } catch (_0x3b63d8) {
                    this[_0xe2b751(0x11e)](_0x3b63d8);
                }
            })[_0x45507d(0xf2)](_0x19d3af => {
                const {
                    statusCode: _0x519bea,
                    statusCode: _0x4afbb4,
                    headers: _0xbce383,
                    body: _0x147a65
                } = _0x19d3af;
                _0xeed8e5(null, {
                    'status': _0x519bea,
                    'statusCode': _0x4afbb4,
                    'headers': _0xbce383,
                    'body': _0x147a65
                }, _0x147a65);
            }, _0xbee03f => {
                const _0x50c773 = _0x45507d,
                    {
                        message: _0x34aa95,
                        response: _0x24a9e6
                    } = _0xbee03f;
                _0xeed8e5(_0x34aa95, _0x24a9e6, _0x24a9e6 && _0x24a9e6[_0x50c773(0xb3)]);
            }));
        } [_0x12d81a(0x124)](_0x47b417, _0x45179c = () => {}) {
            const _0x16f188 = _0x12d81a;
            if (_0x47b417[_0x16f188(0xb3)] && _0x47b417[_0x16f188(0x8b)] && !_0x47b417[_0x16f188(0x8b)][_0x16f188(0xab)] && (_0x47b417[_0x16f188(0x8b)][_0x16f188(0xab)] = _0x16f188(0x8c)), _0x47b417[_0x16f188(0x8b)] && delete _0x47b417['headers']['Content-Length'], this[_0x16f188(0x118)]() || this['isLoon']()) this[_0x16f188(0x118)]() && this[_0x16f188(0xc4)] && (_0x47b417[_0x16f188(0x8b)] = _0x47b417[_0x16f188(0x8b)] || {}, Object[_0x16f188(0xd0)](_0x47b417['headers'], {
                'X-Surge-Skip-Scripting': !0x1
            })), $httpClient[_0x16f188(0x124)](_0x47b417, (_0x4fbe1b, _0xb53c1, _0x563b6d) => {
                const _0x3877a8 = _0x16f188;
                !_0x4fbe1b && _0xb53c1 && (_0xb53c1[_0x3877a8(0xb3)] = _0x563b6d, _0xb53c1[_0x3877a8(0xf3)] = _0xb53c1['status']), _0x45179c(_0x4fbe1b, _0xb53c1, _0x563b6d);
            });
            else {
                if (this[_0x16f188(0x106)]()) _0x47b417[_0x16f188(0x11c)] = _0x16f188(0xa0), this['isNeedRewrite'] && (_0x47b417[_0x16f188(0xe9)] = _0x47b417[_0x16f188(0xe9)] || {}, Object['assign'](_0x47b417[_0x16f188(0xe9)], {
                    'hints': !0x1
                })), $task[_0x16f188(0x98)](_0x47b417)['then'](_0x457b5d => {
                    const {
                        statusCode: _0x2feece,
                        statusCode: _0x1f2fa4,
                        headers: _0x4bb223,
                        body: _0x98c894
                    } = _0x457b5d;
                    _0x45179c(null, {
                        'status': _0x2feece,
                        'statusCode': _0x1f2fa4,
                        'headers': _0x4bb223,
                        'body': _0x98c894
                    }, _0x98c894);
                }, _0x4c7532 => _0x45179c(_0x4c7532));
                else {
                    if (this[_0x16f188(0xd3)]()) {
                        this[_0x16f188(0x102)](_0x47b417);
                        const {
                            url: _0x309ca9,
                            ..._0x41f909
                        } = _0x47b417;
                        this[_0x16f188(0xad)][_0x16f188(0x124)](_0x309ca9, _0x41f909)['then'](_0x31ef98 => {
                            const {
                                statusCode: _0xbe5a03,
                                statusCode: _0x35e45d,
                                headers: _0xca5fc5,
                                body: _0x37942b
                            } = _0x31ef98;
                            _0x45179c(null, {
                                'status': _0xbe5a03,
                                'statusCode': _0x35e45d,
                                'headers': _0xca5fc5,
                                'body': _0x37942b
                            }, _0x37942b);
                        }, _0x160cd7 => {
                            const _0x5c9ee0 = _0x16f188,
                                {
                                    message: _0x48669e,
                                    response: _0x2f5bcd
                                } = _0x160cd7;
                            _0x45179c(_0x48669e, _0x2f5bcd, _0x2f5bcd && _0x2f5bcd[_0x5c9ee0(0xb3)]);
                        });
                    }
                }
            }
        } [_0x12d81a(0xb5)](_0x3df112) {
            const _0x460417 = _0x12d81a;
            let _0x4a0bc1 = {
                'M+': new Date()[_0x460417(0xcf)]() + 0x1,
                'd+': new Date()[_0x460417(0xa6)](),
                'H+': new Date()[_0x460417(0x127)](),
                'm+': new Date()[_0x460417(0xe8)](),
                's+': new Date()[_0x460417(0x123)](),
                'q+': Math[_0x460417(0x9a)]((new Date()[_0x460417(0xcf)]() + 0x3) / 0x3),
                'S': new Date()[_0x460417(0xd5)]()
            };
            /(y+)/ ['test'](_0x3df112) && (_0x3df112 = _0x3df112[_0x460417(0xde)](RegExp['$1'], (new Date()[_0x460417(0xa2)]() + '')[_0x460417(0xa7)](0x4 - RegExp['$1'][_0x460417(0xe7)])));
            for (let _0xc76482 in _0x4a0bc1) new RegExp('(' + _0xc76482 + ')')[_0x460417(0x121)](_0x3df112) && (_0x3df112 = _0x3df112[_0x460417(0xde)](RegExp['$1'], 0x1 == RegExp['$1'][_0x460417(0xe7)] ? _0x4a0bc1[_0xc76482] : ('00' + _0x4a0bc1[_0xc76482])[_0x460417(0xa7)](('' + _0x4a0bc1[_0xc76482])[_0x460417(0xe7)])));
            return _0x3df112;
        } [_0x12d81a(0x116)](_0x2374f6 = _0x3b9c08, _0x19c86b = '', _0x5bab19 = '', _0x2cf3de) {
            const _0x24306a = _0x12d81a,
                _0x31349f = _0x48b372 => {
                    const _0x297086 = _0x5983;
                    if (!_0x48b372) return _0x48b372;
                    if (_0x297086(0x8d) == typeof _0x48b372) return this[_0x297086(0xb0)]() ? _0x48b372 : this['isQuanX']() ? {
                        'open-url': _0x48b372
                    } : this['isSurge']() ? {
                        'url': _0x48b372
                    } : void 0x0;
                    if (_0x297086(0x9f) == typeof _0x48b372) {
                        if (this[_0x297086(0xb0)]()) {
                            let _0xa13e24 = _0x48b372['openUrl'] || _0x48b372[_0x297086(0x110)] || _0x48b372[_0x297086(0x122)],
                                _0x2372aa = _0x48b372[_0x297086(0xbf)] || _0x48b372['media-url'];
                            return {
                                'openUrl': _0xa13e24,
                                'mediaUrl': _0x2372aa
                            };
                        }
                        if (this['isQuanX']()) {
                            let _0xee5373 = _0x48b372['open-url'] || _0x48b372[_0x297086(0x110)] || _0x48b372[_0x297086(0xc6)],
                                _0x789629 = _0x48b372[_0x297086(0xfd)] || _0x48b372[_0x297086(0xbf)];
                            return {
                                'open-url': _0xee5373,
                                'media-url': _0x789629
                            };
                        }
                        if (this[_0x297086(0x118)]()) {
                            let _0x3d403c = _0x48b372[_0x297086(0x110)] || _0x48b372[_0x297086(0xc6)] || _0x48b372[_0x297086(0x122)];
                            return {
                                'url': _0x3d403c
                            };
                        }
                    }
                };
            this['isMute'] || (this[_0x24306a(0x118)]() || this[_0x24306a(0xb0)]() ? $notification['post'](_0x2374f6, _0x19c86b, _0x5bab19, _0x31349f(_0x2cf3de)) : this[_0x24306a(0x106)]() && $notify(_0x2374f6, _0x19c86b, _0x5bab19, _0x31349f(_0x2cf3de)));
            let _0x6469f = ['', _0x24306a(0x9e)];
            _0x6469f[_0x24306a(0x101)](_0x2374f6), _0x19c86b && _0x6469f[_0x24306a(0x101)](_0x19c86b), _0x5bab19 && _0x6469f[_0x24306a(0x101)](_0x5bab19), console[_0x24306a(0x12a)](_0x6469f[_0x24306a(0x11d)]('\x0a')), this[_0x24306a(0xe1)] = this[_0x24306a(0xe1)][_0x24306a(0xdf)](_0x6469f);
        } ['log'](..._0x4d6c5f) {
            const _0x2126bc = _0x12d81a;
            _0x4d6c5f[_0x2126bc(0xe7)] > 0x0 && (this['logs'] = [...this[_0x2126bc(0xe1)], ..._0x4d6c5f]), console[_0x2126bc(0x12a)](_0x4d6c5f[_0x2126bc(0x11d)](this[_0x2126bc(0x10c)]));
        } [_0x12d81a(0x11e)](_0x441445, _0x47ff00) {
            const _0x262c52 = _0x12d81a,
                _0x519177 = !this['isSurge']() && !this[_0x262c52(0x106)]() && !this['isLoon']();
            _0x519177 ? this['log']('', '❗️' + this[_0x262c52(0xd6)] + _0x262c52(0x109), _0x441445[_0x262c52(0xba)]) : this[_0x262c52(0x12a)]('', '❗️' + this[_0x262c52(0xd6)] + ', 错误!', _0x441445);
        } ['wait'](_0x2eeb11) {
            return new Promise(_0x164355 => setTimeout(_0x164355, _0x2eeb11));
        } [_0x12d81a(0x114)](_0x432dcc = {}) {
            const _0x4f2687 = _0x12d81a,
                _0x22b737 = new Date()[_0x4f2687(0xd1)](),
                _0x206f7c = (_0x22b737 - this[_0x4f2687(0xe6)]) / 0x3e8;
            this[_0x4f2687(0x12a)]('', '🔔' + this[_0x4f2687(0xd6)] + _0x4f2687(0x115) + _0x206f7c + ' 秒'), this[_0x4f2687(0x12a)](), (this[_0x4f2687(0x118)]() || this[_0x4f2687(0x106)]() || this[_0x4f2687(0xb0)]()) && $done(_0x432dcc);
        }
    }(_0x3b9c08, _0x519497);
}