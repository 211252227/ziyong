/*
中国人保APP
关键域名gms.ihaoqu.com
查看请求里的accessToken跟authorization
变量
export picchd='accessToken&authorization'
多号@或换行
cron 0 0 * * * picc.js
*/
var version_='jsjiami.com.v7';const _0x1e1065=_0x1528;(function(_0x19c969,_0x4faeb5,_0x1e0624,_0x1fab61,_0x23f2e9,_0x5667a3,_0x55e17d){return _0x19c969=_0x19c969>>0x8,_0x5667a3='hs',_0x55e17d='hs',function(_0x13c8c4,_0x2a26a4,_0x10cfdb,_0x26cc27,_0x10e891){const _0x329721=_0x1528;_0x26cc27='tfi',_0x5667a3=_0x26cc27+_0x5667a3,_0x10e891='up',_0x55e17d+=_0x10e891,_0x5667a3=_0x10cfdb(_0x5667a3),_0x55e17d=_0x10cfdb(_0x55e17d),_0x10cfdb=0x0;const _0x5869b7=_0x13c8c4();while(!![]&&--_0x1fab61+_0x2a26a4){try{_0x26cc27=-parseInt(_0x329721(0x1ff,'@OXF'))/0x1*(parseInt(_0x329721(0x170,'AeOU'))/0x2)+-parseInt(_0x329721(0x21d,'m3fN'))/0x3+-parseInt(_0x329721(0x200,'Jh9u'))/0x4*(-parseInt(_0x329721(0x1e8,'kN@k'))/0x5)+-parseInt(_0x329721(0x18e,'2tdI'))/0x6*(-parseInt(_0x329721(0x189,'Jj8Y'))/0x7)+parseInt(_0x329721(0x238,'TiiI'))/0x8+parseInt(_0x329721(0x199,'GImO'))/0x9+-parseInt(_0x329721(0x1c0,'iG@%'))/0xa;}catch(_0xaa083d){_0x26cc27=_0x10cfdb;}finally{_0x10e891=_0x5869b7[_0x5667a3]();if(_0x19c969<=_0x1fab61)_0x10cfdb?_0x23f2e9?_0x26cc27=_0x10e891:_0x23f2e9=_0x10e891:_0x10cfdb=_0x10e891;else{if(_0x10cfdb==_0x23f2e9['replace'](/[YAFlVdNDnUbOrwESxC=]/g,'')){if(_0x26cc27===_0x2a26a4){_0x5869b7['un'+_0x5667a3](_0x10e891);break;}_0x5869b7[_0x55e17d](_0x10e891);}}}}}(_0x1e0624,_0x4faeb5,function(_0xe108c6,_0x5edae4,_0xc82512,_0x4cbfd2,_0x4d48cd,_0x12d516,_0x1c35ab){return _0x5edae4='\x73\x70\x6c\x69\x74',_0xe108c6=arguments[0x0],_0xe108c6=_0xe108c6[_0x5edae4](''),_0xc82512='\x72\x65\x76\x65\x72\x73\x65',_0xe108c6=_0xe108c6[_0xc82512]('\x76'),_0x4cbfd2='\x6a\x6f\x69\x6e',(0x12c7a3,_0xe108c6[_0x4cbfd2](''));});}(0xcb00,0xb7652,_0x396a,0xcd),_0x396a)&&(version_=_0x396a);function _0x396a(){const _0x449808=(function(){return[version_,'rYxljErsSSjniOOaDbnmdidUA.ONScoCFmNV.wv7==','WRZdKSkyjCkJFYzBWRBdSNRdKZxdHGVdRCkEWQ1kWQVcVJFcMu40W47dLColW6xcVgiYAConWPveWRW1W4ldH0RdJfRcHmohW7b6W6JdJrD1W7FcNdKzW5q','W5xdLSo3WRZdHa','W5lcGNFdT0S','W7BdQSolWOldSa','W4XwWRnsWQNcJSowlXzlW51LC8oeWRTczd7dLSk0W7rpAmkqASozFaZcTmovDv1nFbpcUmkJW6xdHqVdTfBdOhRcNdOAEd9kW6pdQ8kGdaVdLa','WPqJWRHJ','W5NdOmoZWRu','roocUCkNW5NdOf/dMooaOXfFW6aoBXBdSmorh8ojW7JcNczuW5JcKEI/OoAAGSoHW77OR73MSzn7w8oHnSkSW5RcHSkpWOxdP0pcShRdKGeWW47cPJaH','emkzWP0JWRKmWRy','WOVcUKVdOZi','gSkgWOCGW7rlWRD7p2JcI8klWPa','d8oGnr9wW6/dGddcHe/dMYNcK8keW6jNWRdcLuGuBNqqrmoUW4jwxSouWPftbmodqxJcH8keW7HAlCo+WRKzWP/cSahcTJO','scTNW4y','WPjMWOW','kmoPv8kTWR0','WQ3dN+oaQCosFmkoWPC744chp8oAkmkqWRL5WPdcLSk4pbrwmmkuCEI/LEABOSo+6l+O5zMEW4OmertdOx5XWONdRSo9FCoZvJ/dOdbFAa','W752WOFdGYu','WR8gW5ddSYO','WPZcVUobSmo7wHaKW7tJGPbvgmkbW5NdQXldI3CuW6FdLCoGiCogCoI+QUAyQSoX6l215zInWPpcSCkHW7ddSu0ZWOGqxmo+w8oNWQ0gnNtcLa','tSkPCMub','WPuNmsVdLgFcJWPwq3KIW4iRWQPafmk/WRJcPvZdUSofW5ZdPCovz8kTC8kuW53cVSov','pabgtCku','W7NdV8kglSo/W4JcUMZdLq','tYTNW4qw','WOu6WRJdIqldMSoCWOi','WPOiWOTwCa','gCoCaCkM','W5pcG8kZCYy','W6nNWRjXWOq','s8ooW5TGW6PEWRjzh2VcQCko','WP1qBgqT','5B+m5BUk77YY','W4tdKSkeWOddKq','W6Go44kuz8orithcR+obHtBdRa1utJGIWQqBw8oxrSoMW6em6l+15PMUW6xOVy3LMA7cM8oFW7iIw1hdVer0zcxdMCoWW5/cPmomWRf+','fMv9W4RdIYj8','WR5+BLq','WP/cPwFdVW4','pWDbvmk1','W7JdJ8o+WQpdKG','WRrzDMiN','tmkAWOtdJMa','W4ZdSmoqWRRdMa','W4HRWOZcKG','hEocMbv3W4z+W57JG6tcH8oDW4NcNSkBw0rDWRxcQCoxwWJcKvpcQUI+P+AAH8k6WQZORzhMS7/dTCk/jsHndmobbCkBW5vXW7HOW5JdVCorDs3cIdS','jEodUMXhcCkNWPRJGjZcHe/dMYNcK8keW6jNWRdcLuGuBNqqwEI8IUABKeTd6kYE5RoUtKZcJbbLWOFcHmo4wI3dVSk5gCkFWRabWRynyua','WRJcJEobTCofWRvVW4NcSUobHGNdRCk7WQ0yaSkrWPf0W50OsCkfWOpdIUI9P+AyUGVOVkNLMBb0CmoKEfmbBNqQWR5+nSkpW5hdSrRcVIK','W5ddPmo0WQFdVqPw','WQFcGfxcPWPkymoaW5e+smoAWQu','WPf9W4zy','nHD9ACkC','W5b6WQzTWP4','ySk3WOO2W6jkoSo0WOWjk3RcTdP9fv8','yCkTWQ7dVxm','WPr2W6rSdW','WPODcdhdSq','W4RcSeRdHxJcI8kh','W4XuWO1TWOipua','WRLWAey','WOfRW7zW','WPddRCo2jgW','xmkEEKSfWRxcLgVdGa','WOVdUSo6ktpdTYfhWPhcISk7','W7VdKrpdRf4vna','awGJW7RdPgLJfZFcIuyxWOBcJ8kUo8kLfezqomoOtSkCCSkxW4mQWOddUmk2WQ00WR/dKa','W5vuWPnUWOyAvmo1WQqDW6KOt8kiW7yQ','gNWHWPjiWPGqB8oAW6vaumkC','D8kfre0m','bCkOWOeQWPq','sSkyEK0z','W6ZdKXldVrexiCo6W6ilc8oFWOVcUWhcLsq','tSkAEe4cWRhcNhNdKb3cIdVdHmokWRa0WQhcIafmkZ0ccCk/WP4cdCofWOXefSou','WOueW6hdHca','qSojf2JdLa','D1lcTqiyW68','W70UWQPYWRu','rY92W5DtW4TmBCo2W5y','W6fF44kfW44gW5VdGCka44oHW5mmsSo6WQ0OW78rW67dIs3cUCoYc8oa6l6E5PUvWRBOV7BLMRWWB8ozWQldOtCMjSkfsK4jWONcUvhdJ8o3WRS','W6u5l8kbaa','W4CQn8kdkmk4iW','WPBdVmkplCk3','WO1TW6jOiW','W6yyWOddHW','W63dRmkHWPNdVW','W6BcH8oYaCk1oSoZW7Tf','W5i1l8kgyCoRm8kyqqtdSchdGa','rxJcLca4','WRvpW4pcKSoEkmobWQdcVa0PvI8','W5btW5zzW5Saaa','WOnkWPtcJcm','WQJdLmkff0e','W4vCWRldUHC','W5ZdOCkCWPZdU0qdCmkv','xmklzuDgWR3cJ2tdNHVcIa','mrdcUZ7dU8kprq','yddcVCo3W6m','W4hdSbpdMCkP','ASkwWP/dUG','WP5HWORcIri','WPddR8oJpg3cONWbWOZcHmkNhaXCW5tcH8kUgmoaD8kYFCotWPfW','W77JGyCLiSoFCCkj44gVaHeQmmkvzCo4eWxcOSoXW70zWRpdL8km6l2q5PQBlSoJ6k6O5Ro2W5FdPmknieieWRdcUCkIWRFcQSoaWP/cQ0JdT8kUW4yFnq','WQanWP9w','WQ7dSSkUb3O','WOGjWR0uFW','W4mUWP/dT8kZ','W5NdOGddKCo9BmoqWRWHuq','W78r44kEW4bKW4ddJrlJG6FdHxKcCbpcLfNdUmoqW7xcKSkrFW/cKoI9S+AyKG7OViVLMl7cMYqcpaujCh7dNSkNe8ouWOnWySoeWPeL','W73cVmoUmSkQ','W7n8WRbkWRi','k8ohWRu','mK9BW5/dMa','WQvvW7f6','W7pdRdBdOmk7','WPabW40OW5qFymomWPWfW44'].concat((function(){return['F8kEWOxdIhe','WQddJSkjoW','WOhcMNZdKJG','WRyqnIZdLa','WOmQW4pcHrBcLSoNF8ouW6q','W5/dLmoPWOpdQW','W6yQWOLUWRCKga','W7aCWOxdK8kpB8kf','WP4iWOv0AW','WQqdWPycta','WRDsWQBcOX8','WO/cNSklFKizWQ7cQqeIkSkjW5FcTmkHkIdcSwZdICoND23dU00','W7RdT8k5WO3dHq','WOpcI8klBW','W5/cQ8kstIK','DSkEW7tcISk3gCkgruuSWRbhbW','lJrlsSkZ','WQC7W7hdVZq','WOzjW6PKwW','C2RcPHa2','pxLcW7tdHG','WRpdG8kyaCk5kgWoWQpdU23dVN3dHqJdOCkj','WQHqW6PoW7C','amooWP3dGCk0','W4dcSe3dONdcGCkh','WOmRWR4/Ba','WRHPW6nOW4C','W4NdQCoIWRO','WOhcG8krB11pW7G','WPFdISknk2i','WQBdG8kDimk1nN0','W4HhWQLfWQ7dNa','WPeLmYJdJW','W6FcM8k6Aq8w','pSolcmkqW70','jCoNFCkA','WPrpW6hdGuS','s3xdRSowFW','WPjQW6bSmq','WRPPW4ZdI2i','W6u4z8kuW7C','W48ilSkBnq','FL7cHayi','WR8dbaVdLW','W5vPWOpdNcC','W7ddH8kzWQyc','W5W8cmkzkCkU','W6hdU8kqWQSf','W5GQnCkflmkSmG','W6XRE8kqW70','oos7UUI3NUwoO8oSeNFcOmosvZGKW6zQBKSmWRJdVCkqWQCtW5fI','W5/cOmoZiSkZ','W6ddP8kSWPRdTG','W493WPb9WQa','WP0YW5RdGK0WWOFdLfqeW49Dqq','W45IWOrxWO8','WPCpBSkAeW','WQRdH8krfgy','gSocWRVdN8or','W77dQd/dJmkz','WPFcGxNdOH0','W4n1WQhdIre','W63cH2hdV3W','WPH+W73dL2ddHCoD','W4yTWOapc8onWPJcQIiP','WR11W4HQjG','WRrmW45dta','WRddH8kyna','WOuWjqZdIG','W7hdTCkTWRW','rbHuW7C3','p8oQWRldQSkx','WR3cQSo/W6r/wmo8WP4memo+C8of','WOG6W7JcHaddLCoBWPlcLmkExGdcOSoIo8kSsCkNWODXW6JcQHJcNctcJSo/vaSGDW','W6uLWQjdWP0','W7xdUXtdSw4','WQWCWOi5CG','WR81WPPlCa','WQ/dJmkmea','dSoBamkT','WPTpW5NdVLe','W6qRWOfpWOO','W5GHWPXoWOu','ESkcy0uC','WOZdTmoeogZdSt1j','CmkKWOWKWR8vzCkYWPunD3VdTtiJh1ldPSoUW47dTupdGJW+W4RdR3bfWP8woSoYBmkQW5TbldjLW77dKSk+w8kyxmkCW6JdS3tcUCoWmYFcIslcUCkxtJZdKsNdTmobjCozWRpdK8kzAmk4W7JdN8kEWQVcRG','WOe7kHddUq','W6eyWRzAWOa','wZ/cHSoyW4VdLg0','W4VdSSk4WQFdLa','W40DECk/W4e','W5n0WPZcNtBcJ8oHwmoHW53dJtTnqxqszmovWOJdIIPdW6lcUGVcKCohWP9MdwC','W6W1WOjvWR0','WOz9W59CzCoxWOpcKrqjW6C','tti7WONcMhb4oeRcLZHw','A17cUayeW6m','W5BdQcJdH8kk','eJfesSky','WPO2W63dGda','W54oW6/dVuO2vsxdQ8oKuxVdPmoJ5B6/5lYk5yEo5l6O5y2j77Ym5P2g5QQN546u5P6E5lQG5Rw5W7VcSxGigKBdUwtdVdVdMmocza','W7/cH2NdU0a','W7rSWRVdIWe','W43JGzHVWO0fW5JdREobV8oxW7RcJCoiwmkUmCkwoJjQW6a7WRauA+I9QEAyH8kaWR7OR6hMSPD8xbDwxCkxx8oRW7jFkeacESoHWOBdU8kUW7eH','W6OnWOddLSkzjSoEW7NcOJ0rrNK1W5xdSWRdQCoLW7ZdMsBdH8o4sa','a8ogWRNdLCoUrSoEhrLmW60tEMFcPmkcv8kmW77cGvOhWOhdG1BdHmkLW747iwaoW4mzW43cQSklWOlcMmkyc8oKk8kle1ZcUmokpdlcGSkLwmoGW6ldJvBdGCkFWOqRW5ddSmo2brvYlIdcRmkkjmoVCIVcSCopjWTMW4xdI8krbSkBWRFdJ17dQuPfW4a1WOX+eIFcVaSgociVW6zSfHfDoa40WQ/cTCoarmkQFfGGomorWQFdTCoqb3THWRXDuSkgWQXaWRLHkGLBxcFcO8oasSk2gmoXW7PPWQGsW4HLlZpdH8kwjsVcSCkXeY3cGgOWt8kuhGX/yG/dL8oHW6irlSkNW5RcPmoskSoBW7K6W7H6W58HWQBcUHf6WRPZu8oiW7NdVSkfWRC2WRa+WQBdUmk4WPdcR8kUvdbqWRP/WRNcKG9lWRfnWONdItdcSfxdSbqeWR5yW6pdGSkofgCiW4PatxvwW7u8WPhdSutcLWvonJNdTZFcQCkTrCo0WRZcV2xcTeJdOCoIWPpdMSohu8o/','WOaWW7ddMK7dMmoyWO7cHSkl','WRxdTmoTjxldTdibW4pdJCoLxGP1W43cGmk4a8ovnmkCFSkzWObXdH1kW4VdMcbnWOT9pmkyWPmtW61zWORdPSkPhmkQW44CnmkMW4pcJqinW5FcQafHWPpcKYJcK8otDSkPd8kdW53cGCkxWOGwWOZdPIFdLWrDW7NcNCkIW47cO8okW6VcOmomW6WEmmkOW7FdMuPRdZzluL3dIX/dHJBdSCoYbSomWOyVpqSPDH4jneK9kSo+W6C2DSoUWP9EESkom0BdMthcOKZdR8oTnJiKF8k+zX7cMWJdOKxcIHCCWQJdKSoAW4JcUdrgtMVdJ1rXa3PvWQtcOxhcMCoYvmkcfCk+rComiL5hsqqWW7feW6hdVepdQSklxmoqW4PRWQPaW4RcLhJdGsNcSIddSe52WPOlfIm/WOJcVaDUjmosDqdcTSkDlmkvWRKwWQZcI0iUW5ZdNXtdIh15iI9CWQ52W7lcKCkGWPSxW4hdTcRdSCk2jSkzW5DGW78iWQ1IW6isW7NdVGrSDwZdVCoembaP','oLLmW4VdHq','nrtcUWNdUG','W6NdS8k7jfOmWRS','W6JJGjtdOgBdLJyJ44ozAtBdRa1utJGIWQqBw8oxrSoMW6er6l+15PMUW6xcUEITH+AYVCkEW7mXcKZdVer0zcxdMCoWW5/cPmomWRf+W4xdGa4','44oEWPznW5ylW6NJGyfk6l6/5PQz5l6E55MO5ywt6yoj6lsV5yYG5PsX57IKrSk4aa','W5FcRu/dSwe','W4vsz8k/W4q','WPmxWRiQrW'].concat((function(){return['WP7cVxVdOa','WPrlW6JdONC','WOpcS1dcMCoLnCknWOyhySk9W6ddKq','WP7cO8kKWRhdUNyFya','ASkzuNmd','WRNcLLddJI8','W4/dM8kXWOyE','WOdcJ8klALbxW6a','W5lcPmkQEaW','W5ZdNmk4WRldOq','tmk1jmocW4JcHow+IUwKRoobHUESSHK','bmo9WQ3dSCob','W7yrWPhdIa','W7nwWRJcUIi','5B+H5BId776c','W4zHWPVcHbPLW5i','CqRJGj7dNCopj2Wy44cDW4vggSkvWOVcV2pdTGqUpJ7cPe7cKEI+HEAAGmop6l6B5zIWWQFcPSoKzCkSW5RdPWHkW5KFWRhdS8oQgGVcJtW','W4f4WONdMqy','W4ldMthdL24','A8kGWPq9WRG','W4JdLmkTWRJdNW','jCoOWRtdVSo3','WOdcKmkwFH0dW6xdOX0PoCkFWPW','WQ1lWQtcKZi','t8oAiv/dVq','WOVcTMhdTtO','fCkUWQKaWPe','WR/cKxNdGcW','WQNcHhRdOqC','WQ3cNuxcMH3dOJ8FaSogWPhcM15tj8k5jmkud8ottg5LWQyDWRZcMuqThmo0','ACkLWRldI1a','W7abCCkuW6K','tmomW55HW6TBW6DRpM/cRSk8WOe','WPfuW61Ltq','WQOnqSkkdW','WQdcHfpcPG9ezSkJWReoqmkmW5ddPuRdHYSEW6RdKmk5lSonleuWW6JcK8k2W4xcTCk0','ENVdRmos','W6nbWRldNtS','W49rWRjZWRm','W5ZdPCoGWRBdJq','mWFcVqxdOa','ttVcG8om','W7/dOCk5jCo+','WOeRWQjrDa','WQy4E8kedSooW6SAWOpcQmoEW5OpW6bJW4u','BxhdSCo1rq','W5BdV8kTWQuh','WQxdHCk9iCkc','tCkQWPeyWPS','WQxcKmkuwf4','mbfED8kOW5VdRtJdN8oNW41lW7ldKdygW71MDapdHSkPWOTmutPWlZGeEar1gCocW74tbxVcM8kNmCkOW7hcVY3cKxKWW5RcGN7dISoDACkR','gCkDWPOX','W6NdGmofWR3dMa','CXpcOmo/W6a','W4XHWPZcUHrSW4pdLW','cCo6w8kqWPy','W4FdPmkhWR4G','W4ldSmkDWOBdTeqp','WP1VW7RdLhlcMmkxwSkmWP82xwnlW5KnWQBcJSoMW4ZdGY8CW47dHa','W6ZcKSoEsGf7W4/dUmkkW6WdWQjj','imogW67dN8oJsCoxvW','W44xWPddS8k9','WPNdQ8oNihFdUZjAWP/cJmk7uuHkW4VcGa','W77dGbtdR0XiFSk8W7Spv8oEW4RcS1/cNYLkW7tcI8kYCCovlH0QWPBcJmkBWRBcGmkfWR7cPf9pW4vDmSkQaCk0W7LvrsZdNI4OWQNdUSktBM4/W5CebhhcLCkXW4ynmYtcRr7cHMr7WPlcPf3dQtKJ','W7TZuSk3W6K','W7LpvmkpW4W','W6hcNmomb8k4pmo2W7HVvMWdWR3dGW','gmoiWQ3dOCku','wUs6MEI1G+wmToocQ8kzWQBdUsf1','WQNdQSo6p20','WOCJmY7dK2pcHXHg','a3DLW5hdRq','W7JdSGZdIhi','W4zcWRj3WQ4','WPinW43dHsS','AdT5W54/','W7pdHHldSe0','t0pdJCo8xa','W4tcTe3dLxe','D8k4wg8Y','DSk/W5u3WQ1miSo4','D8obW5nTW6vwW64JzdNdL8ocW4JdN8oUWPtcJZ5TyCoa5ywC5OMh5yQmwW','ECkGWOG4WQvmk8oPWOyfAZBcSsq8gb3cPCk0W4JdOLRdGY88WOtdGtmHW75SrCo3','W7ldLrtdVG','W7xdTs3dVhS','WPO4BctdNgFcHHS','WOpcMN7dMJG','W4nuWRT7WPm','kwHxW4/dGW','WOaYldFdMhBcJWPkxNjBW4K0WRbl','WQb3n3yKCcS5WPddRwVcKSosACk3W7tdUeiyW4HCbSk6WQ3cN1tdSmopBK/cGaFdGSoDxa','l8ozfSk2W5C','772X5y2J5zIo772k','zhpdSmovaSkdWQtdTvFdUdnwWPePWOWygq','W5KLWObHWQi','WPT0WQpdH2ddGCoqea','WOf3WPZcTHG','WOOLW6xdHGRdMSovWPpcMCkbx1JcRCoJESkSamoZWOb1W7ZcUXNcJsVcM8o/te50jmkcW6K','W5pdRSkQWRFdVq5BWO0','W6CaWPxdVmkm','rgNcMHec','tmkrWQ3dV0a','WRL+W6vdaa','WO5oA0uL','W4nsWPu','W5hdK8kLWPeI','f8oChmkPW60','vCoqaLBdSa','hCkctc/cMtBcHmoiWOFdNCojWP7cM1TexCk1WQNdL1SiWPftWRDdWPxcP8kXWPVcGmoOW7DQEvamW4efWPVdLxhdUgJdMmo9W5f1mmkvjNvy6iwL5P2m5OU96koTx8kgzEwpPos5U+AwOoMuKCoraLFcGCkdBcdVV7G','qs9GW5qFW41f','WO0YeYddHq','B0hdImoqxq'];}()));}()));}());_0x396a=function(){return _0x449808;};return _0x396a();};const $=new Env(_0x1e1065(0x187,'I0!@')),axios=require('axios');function _0x1528(_0x1cf0e5,_0x2dcf3a){const _0x396a7e=_0x396a();return _0x1528=function(_0x1528da,_0x2d2b98){_0x1528da=_0x1528da-0x168;let _0x3d983d=_0x396a7e[_0x1528da];if(_0x1528['PqKzBW']===undefined){var _0x45360e=function(_0x5794b0){const _0x12748f='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x461d30='',_0x3a0326='';for(let _0x199e53=0x0,_0x131ab0,_0x3af65d,_0x3305e4=0x0;_0x3af65d=_0x5794b0['charAt'](_0x3305e4++);~_0x3af65d&&(_0x131ab0=_0x199e53%0x4?_0x131ab0*0x40+_0x3af65d:_0x3af65d,_0x199e53++%0x4)?_0x461d30+=String['fromCharCode'](0xff&_0x131ab0>>(-0x2*_0x199e53&0x6)):0x0){_0x3af65d=_0x12748f['indexOf'](_0x3af65d);}for(let _0x547a44=0x0,_0xe87797=_0x461d30['length'];_0x547a44<_0xe87797;_0x547a44++){_0x3a0326+='%'+('00'+_0x461d30['charCodeAt'](_0x547a44)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x3a0326);};const _0x2072ba=function(_0x54e73a,_0x156c18){let _0x552c0c=[],_0x2cf945=0x0,_0x4e8154,_0x3503b9='';_0x54e73a=_0x45360e(_0x54e73a);let _0x11edd9;for(_0x11edd9=0x0;_0x11edd9<0x100;_0x11edd9++){_0x552c0c[_0x11edd9]=_0x11edd9;}for(_0x11edd9=0x0;_0x11edd9<0x100;_0x11edd9++){_0x2cf945=(_0x2cf945+_0x552c0c[_0x11edd9]+_0x156c18['charCodeAt'](_0x11edd9%_0x156c18['length']))%0x100,_0x4e8154=_0x552c0c[_0x11edd9],_0x552c0c[_0x11edd9]=_0x552c0c[_0x2cf945],_0x552c0c[_0x2cf945]=_0x4e8154;}_0x11edd9=0x0,_0x2cf945=0x0;for(let _0x1fe694=0x0;_0x1fe694<_0x54e73a['length'];_0x1fe694++){_0x11edd9=(_0x11edd9+0x1)%0x100,_0x2cf945=(_0x2cf945+_0x552c0c[_0x11edd9])%0x100,_0x4e8154=_0x552c0c[_0x11edd9],_0x552c0c[_0x11edd9]=_0x552c0c[_0x2cf945],_0x552c0c[_0x2cf945]=_0x4e8154,_0x3503b9+=String['fromCharCode'](_0x54e73a['charCodeAt'](_0x1fe694)^_0x552c0c[(_0x552c0c[_0x11edd9]+_0x552c0c[_0x2cf945])%0x100]);}return _0x3503b9;};_0x1528['oTdPRn']=_0x2072ba,_0x1cf0e5=arguments,_0x1528['PqKzBW']=!![];}const _0x116612=_0x396a7e[0x0],_0x485f38=_0x1528da+_0x116612,_0x14511b=_0x1cf0e5[_0x485f38];return!_0x14511b?(_0x1528['JmQJMn']===undefined&&(_0x1528['JmQJMn']=!![]),_0x3d983d=_0x1528['oTdPRn'](_0x3d983d,_0x2d2b98),_0x1cf0e5[_0x485f38]=_0x3d983d):_0x3d983d=_0x14511b,_0x3d983d;},_0x1528(_0x1cf0e5,_0x2dcf3a);}let request=require(_0x1e1065(0x191,'VO]C'));request=request['defaults']({'jar':!![]});const {log}=console,Notify=0x1,debug=0x0;let picchd=($[_0x1e1065(0x1b8,'3F!w')]()?process[_0x1e1065(0x185,'GImO')][_0x1e1065(0x2b6,'Epa[')]:$[_0x1e1065(0x204,'Q19s')](_0x1e1065(0x1ab,'B*(V')))||'',picchdArr=[],data='',msg='';var hours=new Date()[_0x1e1065(0x233,'iG@%')](),timestamp=Math[_0x1e1065(0x21e,'O5g7')](new Date()[_0x1e1065(0x1a2,'allO')]())[_0x1e1065(0x1de,')wLw')]();!(async()=>{const _0x3989e3=_0x1e1065,_0x5c6b28={'LndUW':function(_0x465c2f,_0x5f15e9){return _0x465c2f(_0x5f15e9);},'doMfZ':'undefined','AatQH':function(_0x51e0c0,_0x2628b0){return _0x51e0c0!==_0x2628b0;},'QWOKp':_0x3989e3(0x212,'GImO'),'lqfXv':function(_0x3781d1,_0x2b4845){return _0x3781d1===_0x2b4845;},'RhYvi':_0x3989e3(0x1c5,'@OXF'),'hWphX':function(_0x2b4463){return _0x2b4463();},'ENywN':function(_0x18861d,_0x5dcc6d){return _0x18861d+_0x5dcc6d;},'WyFLT':function(_0x3c416d,_0x9671b2){return _0x3c416d+_0x9671b2;},'qinSS':function(_0x1c8bc5,_0x14facb){return _0x1c8bc5*_0x14facb;},'DqjyA':function(_0x3a02a7,_0xb45383){return _0x3a02a7*_0xb45383;},'JTnMC':function(_0x52a92d,_0x986a09){return _0x52a92d(_0x986a09);},'NawzE':function(_0x45a77d,_0x4e26e1){return _0x45a77d(_0x4e26e1);},'BZcxg':_0x3989e3(0x262,'pF5r'),'XmtLp':'sOSOX','nrWnG':function(_0x4631f7){return _0x4631f7();}};if(typeof $request!==_0x5c6b28[_0x3989e3(0x1ea,'@OXF')])_0x5c6b28['AatQH'](_0x5c6b28[_0x3989e3(0x291,'Uv7k')],_0x5c6b28[_0x3989e3(0x24a,'vr!p')])?_0x243ef5(''+_0x43ecb8[_0x3989e3(0x1ba,'3F!w')]):await GetRewrite();else{if(_0x5c6b28['lqfXv']('Tmixb',_0x5c6b28[_0x3989e3(0x255,'kN@k')]))_0x5c6b28[_0x3989e3(0x23a,'VO]C')](_0x12748f,_0x3989e3(0x1f9,'Uv7k')+_0x461d30);else{if(!await _0x5c6b28['hWphX'](Envs))return;else{_0x5c6b28[_0x3989e3(0x19b,'(*gJ')](log,_0x3989e3(0x269,'nCXX')+new Date(_0x5c6b28[_0x3989e3(0x293,'D88D')](_0x5c6b28[_0x3989e3(0x171,'zl64')](new Date()[_0x3989e3(0x176,'6VvO')](),_0x5c6b28[_0x3989e3(0x18a,'pF5r')](_0x5c6b28[_0x3989e3(0x248,'6hA[')](new Date()[_0x3989e3(0x19f,')lgJ')](),0x3c),0x3e8)),_0x5c6b28[_0x3989e3(0x228,'TP4q')](_0x5c6b28[_0x3989e3(0x288,'B*(V')](0x8,0x3c)*0x3c,0x3e8)))[_0x3989e3(0x23f,'eZYN')]()+_0x3989e3(0x278,'qM9R')),_0x5c6b28[_0x3989e3(0x1eb,']FAd')](log,_0x3989e3(0x1ed,'zl64')),_0x5c6b28['NawzE'](log,_0x3989e3(0x24e,'m3fN')+picchdArr[_0x3989e3(0x1e9,'Epa[')]+_0x3989e3(0x1bc,'huv2'));debug&&_0x5c6b28[_0x3989e3(0x1dc,'!0JJ')](log,'【debug】\x20这是你的全部账号数组:\x0a\x20'+picchdArr);for(let _0x15d56d=0x0;_0x15d56d<picchdArr[_0x3989e3(0x1a9,'SM05')];_0x15d56d++){if(_0x5c6b28['AatQH'](_0x5c6b28[_0x3989e3(0x168,')lgJ')],_0x5c6b28[_0x3989e3(0x1b2,'#X$v')])){let _0x531235=_0x15d56d+0x1;addNotifyStr(_0x3989e3(0x207,'s5!t')+_0x531235+_0x3989e3(0x241,'q9Nr'),!![]),picchd=picchdArr[_0x15d56d],accessToken=picchd[_0x3989e3(0x172,'TiiI')]('&')[0x0],authorization=picchd[_0x3989e3(0x210,'huv2')]('&')[0x1],await _0x5c6b28[_0x3989e3(0x1a0,'AeOU')](pageInitialization,_0x3989e3(0x220,'e7W(')),await _0x5c6b28[_0x3989e3(0x1a7,'TiiI')](pageInitialization,'f92e639f09554f279f6d75f2b3c2c356'),await _0x5c6b28[_0x3989e3(0x26e,'D88D')](everydaySignin),await _0x5c6b28[_0x3989e3(0x29e,']FAd')](pageInitialization1);}else _0x3c85b0[_0x3989e3(0x225,'6VvO')](_0x1798fe);}await _0x5c6b28[_0x3989e3(0x208,'GImO')](SendMsg,msg);}}}})()[_0x1e1065(0x24b,'allO')](_0x171ded=>log(_0x171ded))[_0x1e1065(0x1a6,'Q19s')](()=>$[_0x1e1065(0x221,'vr!p')]());async function pageInitialization(_0x247de8){const _0x4190b2=_0x1e1065,_0x519888={'nFlWM':function(_0x57f118,_0x1231ac){return _0x57f118(_0x1231ac);},'hRGPI':function(_0x49cc2f,_0x546c5a){return _0x49cc2f(_0x546c5a);},'naNRH':function(_0x314e05,_0x2da52b){return _0x314e05===_0x2da52b;},'ajVUG':_0x4190b2(0x282,']FAd'),'zGhmx':_0x4190b2(0x1d6,'2cAl'),'UAxlG':function(_0x53b368,_0x1345ea){return _0x53b368!==_0x1345ea;},'TNmCh':'Sfdom','gbkSn':function(_0x31534b,_0x2ead86){return _0x31534b(_0x2ead86);},'xzzNo':_0x4190b2(0x22d,'huv2'),'XoLog':function(_0x37bff2){return _0x37bff2();},'Zmgks':function(_0x5e38da,_0x54aace){return _0x5e38da===_0x54aace;},'hvahr':_0x4190b2(0x25b,'!0JJ'),'TSEYI':'YeTQH','TmQHQ':_0x4190b2(0x1fd,'Uv7k'),'EDIAD':_0x4190b2(0x1df,'huv2'),'NQHWX':_0x4190b2(0x2b8,'6hA['),'xTozL':_0x4190b2(0x25f,'D88D'),'TABiD':_0x4190b2(0x1f1,'VO]C'),'PviwM':'Mozilla/5.0\x20(Linux;\x20Android\x2010;\x20PCAM00\x20Build/QKQ1.190918.001;\x20wv)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Version/4.0\x20Chrome/77.0.3865.92\x20Mobile\x20Safari/537.36\x20PBrowser/3.15.0\x20PiccApp/6.13.2\x20&&webViewInfo=3.15.0&&appInfo=piccApp&&appVersion=6.13.2;webank/h5face;webank/2.0','rmzeq':'application/json','ducMp':_0x4190b2(0x1d3,'(*gJ'),'gsLiM':_0x4190b2(0x1e7,'I0!@'),'qgdKw':_0x4190b2(0x271,'SM05'),'qrHnQ':_0x4190b2(0x2ac,'kN@k')};return new Promise(_0x474a99=>{const _0x156c9b=_0x4190b2,_0x2a3b61={'tQpqF':function(_0x2b1682){return _0x2b1682();},'PGert':function(_0xc73e28,_0x575ad1){const _0x20b9ad=_0x1528;return _0x519888[_0x20b9ad(0x294,'IPi1')](_0xc73e28,_0x575ad1);},'HqLeY':function(_0x253e8c,_0x4fff54){const _0x402562=_0x1528;return _0x519888[_0x402562(0x217,'m3fN')](_0x253e8c,_0x4fff54);},'SbewM':function(_0xbca46,_0x4662e7){const _0x28acbf=_0x1528;return _0x519888[_0x28acbf(0x27b,'s5!t')](_0xbca46,_0x4662e7);},'BXsDT':_0x519888[_0x156c9b(0x2a2,'I0!@')],'OhTfF':_0x519888[_0x156c9b(0x1b3,'3F!w')],'BCBAH':function(_0x39f180,_0x264ac5){const _0x29a9bb=_0x156c9b;return _0x519888[_0x29a9bb(0x1d1,'&N5f')](_0x39f180,_0x264ac5);},'DwJxT':_0x156c9b(0x203,'d$)5'),'FyLMl':_0x519888[_0x156c9b(0x266,'d$)5')],'nJIvL':function(_0x4a9eae,_0x32337d){const _0x5cdaf4=_0x156c9b;return _0x519888[_0x5cdaf4(0x292,']FAd')](_0x4a9eae,_0x32337d);},'JRXIe':function(_0xaf9ea2,_0x2a3de1){const _0x276194=_0x156c9b;return _0x519888[_0x276194(0x245,'e7W(')](_0xaf9ea2,_0x2a3de1);},'TQqpO':function(_0x9d2f50,_0x5c0600){return _0x9d2f50(_0x5c0600);},'xlhNg':_0x156c9b(0x280,'qM9R'),'uWNAR':_0x519888[_0x156c9b(0x1e6,'!0JJ')],'bUnWw':function(_0x4b7084){const _0xccb3b2=_0x156c9b;return _0x519888[_0xccb3b2(0x2af,'qM9R')](_0x4b7084);}};if(_0x519888[_0x156c9b(0x1a4,'AeOU')](_0x519888[_0x156c9b(0x2a8,')wLw')],_0x519888[_0x156c9b(0x27e,'(*gJ')]))_0x2a3b61['tQpqF'](_0x397329);else{var _0x445b7a={'method':_0x519888[_0x156c9b(0x20f,'e7W(')],'url':_0x519888[_0x156c9b(0x216,'Uv7k')],'headers':{'Host':_0x156c9b(0x25a,'vr!p'),'Connection':_0x519888['NQHWX'],'Content-Length':'2','Pragma':_0x156c9b(0x24d,'huv2'),'Cache-Control':_0x519888[_0x156c9b(0x2b0,'m3fN')],'accessToken':accessToken,'Origin':_0x519888[_0x156c9b(0x231,'D88D')],'User-Agent':_0x519888[_0x156c9b(0x2ba,'3F!w')],'Sec-Fetch-Mode':_0x156c9b(0x2a7,'AeOU'),'Content-Type':_0x519888['rmzeq'],'Accept':_0x156c9b(0x25e,'(*gJ'),'authorization':authorization,'X-Requested-With':_0x519888['ducMp'],'Sec-Fetch-Site':_0x519888[_0x156c9b(0x246,'Jj8Y')],'Referer':_0x519888[_0x156c9b(0x1ce,'YUJT')],'Accept-Encoding':_0x156c9b(0x16d,'3F!w'),'Accept-Language':_0x519888['qrHnQ']},'data':'{}'};debug&&(_0x519888[_0x156c9b(0x1d0,'6hA[')](log,_0x156c9b(0x17c,'YUJT')),log(JSON['stringify'](_0x445b7a))),axios[_0x156c9b(0x1e2,'XIBT')](_0x445b7a)['then'](async function(_0x1f996e){const _0x4e94d2=_0x156c9b,_0x236da0={'AkSAk':function(_0x20f99a,_0x30432d){const _0x1c885c=_0x1528;return _0x2a3b61[_0x1c885c(0x1c2,'wym@')](_0x20f99a,_0x30432d);}};_0x2a3b61['HqLeY'](log,data);try{if(_0x2a3b61[_0x4e94d2(0x22b,'d$)5')](_0x2a3b61[_0x4e94d2(0x268,'nCXX')],_0x2a3b61[_0x4e94d2(0x18c,'Uv7k')]))_0x2a3b61[_0x4e94d2(0x19d,'Epa[')](_0x48866f);else{data=_0x1f996e[_0x4e94d2(0x226,'XIBT')];debug&&(_0x2a3b61['BCBAH'](_0x2a3b61[_0x4e94d2(0x1ef,'2tdI')],_0x2a3b61[_0x4e94d2(0x19e,'kN@k')])?(_0x2a3b61[_0x4e94d2(0x192,'TP4q')](log,'\x0a\x0a【debug】===============这是\x20返回data=============='),_0x2a3b61[_0x4e94d2(0x17a,'zl64')](log,_0x1f996e[_0x4e94d2(0x179,'pF5r')])):(_0x3305e4(_0x4e94d2(0x274,'GImO')),_0x236da0[_0x4e94d2(0x188,'@OXF')](_0x547a44,_0xe87797[_0x4e94d2(0x243,'YUJT')](_0x54e73a))));if(data[_0x4e94d2(0x297,'iG@%')]==0x0)sId=data[_0x4e94d2(0x279,'6hA[')][_0x4e94d2(0x265,'2tdI')],await _0x2a3b61[_0x4e94d2(0x1c8,'allO')](fulfilTask,_0x247de8);else _0x2a3b61[_0x4e94d2(0x264,'IPi1')](log,data);}}catch(_0x130bae){_0x2a3b61['xlhNg']!==_0x4e94d2(0x270,'D88D')?_0x2a3b61[_0x4e94d2(0x2a3,'YUJT')](log,''+data[_0x4e94d2(0x2ab,'e7W(')]):(_0x5e3170=_0x38eb9f[_0x4e94d2(0x273,'D88D')],_0x456d05&&(_0xb17e93('\x0a\x0a【debug】===============这是\x20返回data=============='),_0x12ccf7(_0x18baea[_0x4e94d2(0x197,'Q19s')])),_0x2a3b61['PGert'](_0x58254d,_0xa28e09[_0x4e94d2(0x26a,'6hA[')]));}})[_0x156c9b(0x1f6,'6VvO')](function(_0x593db3){const _0x9b4ce5=_0x156c9b;console[_0x9b4ce5(0x1b6,'2tdI')](_0x593db3);})['then'](_0x5f41d8=>{const _0x19b646=_0x156c9b;_0x2a3b61[_0x19b646(0x16e,'Epa[')](_0x2a3b61[_0x19b646(0x26f,'allO')],_0x2a3b61[_0x19b646(0x1e1,'!0JJ')])?(_0x1b7cf3=_0x16c30e['data'][_0x19b646(0x256,'YUJT')],_0xfaab7b(_0x577bd1)):_0x2a3b61[_0x19b646(0x18f,'D88D')](_0x474a99);});}});}async function everydaySignin(){const _0x55bca5=_0x1e1065,_0x2a9eed={'BZZRR':function(_0x5cce3e,_0x530f53){return _0x5cce3e(_0x530f53);},'YneJn':function(_0x39a524,_0x2359aa){return _0x39a524(_0x2359aa);},'uZQtH':_0x55bca5(0x1c6,'Uv7k'),'esVzf':function(_0x34d075,_0x4de6b5){return _0x34d075===_0x4de6b5;},'aToeJ':'jNOLc','IbBZL':function(_0x3fa04e,_0x1884a4){return _0x3fa04e(_0x1884a4);},'gOPBC':function(_0x412109){return _0x412109();},'sIVGt':'POST','beEep':'https://zgrb.epicc.com.cn/G-HAPP/h/AppSigninNewController/everydaySignin','MhVnF':_0x55bca5(0x25c,'CKXm'),'Mjeqs':_0x55bca5(0x237,'CKXm'),'JFNCI':_0x55bca5(0x1f4,')wLw'),'Qqmss':_0x55bca5(0x23b,')wLw'),'hOnZq':_0x55bca5(0x281,'YUJT'),'EVsrk':_0x55bca5(0x175,'qM9R'),'AWkQY':_0x55bca5(0x213,'Q19s'),'MDZvp':'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7','Ujsum':function(_0x10074b,_0x2ceef3){return _0x10074b+_0x2ceef3;},'jmsPg':function(_0x52a028,_0x33394b){return _0x52a028+_0x33394b;},'jeWGd':function(_0x45ba94,_0x2649b4){return _0x45ba94!==_0x2649b4;},'GOvQG':_0x55bca5(0x227,'zoS3')};return new Promise(_0x3ad5d3=>{const _0x16e2ac=_0x55bca5,_0x25bb7d={'KFeui':function(_0x540210,_0x27aae1){const _0x4e0375=_0x1528;return _0x2a9eed[_0x4e0375(0x1a3,'2cAl')](_0x540210,_0x27aae1);},'HdgRu':function(_0x3757c7,_0x5ec24d){const _0x149647=_0x1528;return _0x2a9eed[_0x149647(0x1fb,'a5MK')](_0x3757c7,_0x5ec24d);},'HYKDN':function(_0x1f4cae,_0x21fcc3){return _0x2a9eed['BZZRR'](_0x1f4cae,_0x21fcc3);},'UDNvo':_0x2a9eed[_0x16e2ac(0x1b7,'d$)5')],'HTkVB':function(_0x29bb2f,_0x4c3e45){const _0x36981f=_0x16e2ac;return _0x2a9eed[_0x36981f(0x23e,'a5MK')](_0x29bb2f,_0x4c3e45);},'ByOlj':_0x16e2ac(0x1cb,'I0!@'),'qcQtR':function(_0x48f5a7,_0x400697){return _0x48f5a7!==_0x400697;},'yXXoH':_0x2a9eed[_0x16e2ac(0x1ae,'CKXm')],'nQtnC':function(_0x50cb07,_0x429316){return _0x50cb07(_0x429316);},'FJPla':function(_0x5dc9cb,_0x280c82){return _0x2a9eed['IbBZL'](_0x5dc9cb,_0x280c82);},'BmoUB':function(_0x161db8,_0x1c2ef2){return _0x161db8==_0x1c2ef2;},'yeRgx':function(_0x192ad9,_0x51fc76){return _0x192ad9(_0x51fc76);},'DxmSG':function(_0x3a7fce){const _0xe39880=_0x16e2ac;return _0x2a9eed[_0xe39880(0x23d,'a5MK')](_0x3a7fce);}};var _0x2f6ee2={'method':_0x2a9eed[_0x16e2ac(0x206,'Jh9u')],'url':_0x2a9eed[_0x16e2ac(0x254,'Jj8Y')],'headers':{'Host':_0x16e2ac(0x2b2,'e7W('),'Connection':'keep-alive','Content-Length':'51','Pragma':_0x16e2ac(0x285,'(*gJ'),'Cache-Control':_0x2a9eed[_0x16e2ac(0x253,'Uv7k')],'accessToken':accessToken,'Origin':_0x2a9eed['Mjeqs'],'User-Agent':_0x2a9eed['JFNCI'],'Sec-Fetch-Mode':_0x16e2ac(0x2a6,'IPi1'),'Content-Type':_0x2a9eed[_0x16e2ac(0x242,')wLw')],'Accept':_0x2a9eed[_0x16e2ac(0x183,'eZYN')],'authorization':authorization,'X-Requested-With':_0x16e2ac(0x1e5,'2tdI'),'Sec-Fetch-Site':_0x2a9eed[_0x16e2ac(0x205,'B*(V')],'Referer':_0x16e2ac(0x26d,')lgJ'),'Accept-Encoding':_0x2a9eed[_0x16e2ac(0x180,'VO]C')],'Accept-Language':_0x2a9eed['MDZvp']},'data':_0x2a9eed[_0x16e2ac(0x258,'q9Nr')](_0x2a9eed['jmsPg']('{\x22body\x22:{\x22sId\x22:\x22',sId),_0x16e2ac(0x27a,'2tdI'))};debug&&(_0x2a9eed[_0x16e2ac(0x1a1,'&N5f')](_0x16e2ac(0x1b5,'YUJT'),_0x2a9eed[_0x16e2ac(0x28b,'IPi1')])?(log(_0x16e2ac(0x299,'qM9R')),log(JSON[_0x16e2ac(0x16c,'eZYN')](_0x2f6ee2))):_0x5135bc(''+_0x2008f5[_0x16e2ac(0x275,'m3fN')])),axios[_0x16e2ac(0x1a8,')lgJ')](_0x2f6ee2)[_0x16e2ac(0x1cf,'d$)5')](async function(_0x577975){const _0x36163a=_0x16e2ac,_0x35c015={'IjJZM':function(_0x50a2f8,_0x3e0ad1){return _0x50a2f8(_0x3e0ad1);},'Nmvpp':function(_0x3b0040,_0x3dafcc){const _0x420ea9=_0x1528;return _0x25bb7d[_0x420ea9(0x198,'B*(V')](_0x3b0040,_0x3dafcc);}};if(_0x36163a(0x286,'TP4q')===_0x25bb7d[_0x36163a(0x25d,'zl64')])_0x25bb7d['KFeui'](_0x4e2b81,_0x36163a(0x20d,'kN@k')),_0x25bb7d['HdgRu'](_0xd07b55,_0x479a03[_0x36163a(0x29d,'I0!@')]);else try{if(_0x25bb7d['HTkVB'](_0x25bb7d[_0x36163a(0x16b,'Jh9u')],_0x25bb7d[_0x36163a(0x235,'d$)5')])){data=_0x577975[_0x36163a(0x1cd,')lgJ')];debug&&(_0x25bb7d[_0x36163a(0x218,'Uv7k')]('DCZGM',_0x25bb7d[_0x36163a(0x247,'(*gJ')])?(_0x25bb7d[_0x36163a(0x2b4,'(*gJ')](log,'\x0a\x0a【debug】===============这是\x20返回data=============='),_0x25bb7d['FJPla'](log,_0x577975[_0x36163a(0x16a,'VO]C')])):(_0x25bb7d['HdgRu'](_0x20db11,_0x36163a(0x182,'CKXm')),_0x1838ab(_0x3cdb88[_0x36163a(0x179,'pF5r')])));if(_0x25bb7d[_0x36163a(0x295,'pF5r')](data['code'],0x0))_0x25bb7d[_0x36163a(0x26b,'YUJT')](log,data[_0x36163a(0x20c,'iG@%')]);else log(data[_0x36163a(0x29b,'D88D')]);}else _0x35c015[_0x36163a(0x177,'XIBT')](_0x4e8154,_0x36163a(0x27c,'allO')),_0x35c015[_0x36163a(0x27d,'2tdI')](_0x3503b9,_0x11edd9[_0x36163a(0x273,'D88D')]);}catch(_0x1efd94){_0x25bb7d[_0x36163a(0x1b4,'Epa[')](log,''+data[_0x36163a(0x20c,'iG@%')]);}})['catch'](function(_0x499d59){const _0x1310e0=_0x16e2ac;_0x25bb7d[_0x1310e0(0x22c,')lgJ')]('RtgiZ','rtecg')?console[_0x1310e0(0x19c,'O5g7')](_0x499d59):_0xcc8b0[_0x1310e0(0x2b1,'qM9R')](_0x1c4a90);})[_0x16e2ac(0x1d9,'q9Nr')](_0x45bb48=>{const _0x4291a4=_0x16e2ac;_0x25bb7d[_0x4291a4(0x1ac,'q9Nr')](_0x3ad5d3);});});}async function fulfilTask(_0x9ff9bc){const _0x1643a9=_0x1e1065,_0x1fd0a2={'adgbQ':_0x1643a9(0x2a1,'pF5r'),'CRLpr':function(_0x46aaaf,_0x3c3be0){return _0x46aaaf!==_0x3c3be0;},'cAMcD':_0x1643a9(0x222,'2tdI'),'ksuQi':_0x1643a9(0x1b9,'d$)5'),'BGwki':function(_0x305759,_0x455037){return _0x305759(_0x455037);},'BAXDc':_0x1643a9(0x1c7,'2tdI'),'TkxcS':_0x1643a9(0x184,'Jj8Y'),'SYNey':function(_0x31f9eb){return _0x31f9eb();},'qcxjS':function(_0x559eb3,_0x5d7a3b){return _0x559eb3(_0x5d7a3b);},'OfnZA':'EsZQh','qpHCr':_0x1643a9(0x17d,'TP4q'),'pWyeW':'https://zgrb.epicc.com.cn/G-HAPP/h/AppSigninNewController/fulfilTask','WwVHe':_0x1643a9(0x2a0,'huv2'),'qjZXO':_0x1643a9(0x181,'@OXF'),'gvRUy':_0x1643a9(0x252,'YUJT'),'CeCqe':_0x1643a9(0x195,'Q19s'),'pxvGx':'cors','pdyTX':_0x1643a9(0x229,'wym@'),'oSzIl':_0x1643a9(0x2aa,')wLw'),'BVLog':_0x1643a9(0x22f,']FAd'),'tXaOD':_0x1643a9(0x277,'m3fN'),'UbWxP':_0x1643a9(0x257,'IPi1')};return new Promise(_0x11184a=>{const _0x4cc652=_0x1643a9,_0x19d064={'XRPMY':function(_0x2a00e2,_0x2884dd){return _0x2a00e2(_0x2884dd);},'FPDXN':_0x1fd0a2[_0x4cc652(0x224,'D88D')],'AYBro':function(_0x7f96c3,_0x5a073a){return _0x1fd0a2['CRLpr'](_0x7f96c3,_0x5a073a);},'UAfzp':_0x4cc652(0x1e4,'#X$v'),'KUCFo':function(_0x3a09cb,_0xdb95ca){return _0x3a09cb(_0xdb95ca);},'vQaMh':function(_0x543517,_0x2e7cb8){const _0x2f10ea=_0x4cc652;return _0x1fd0a2[_0x2f10ea(0x261,'Epa[')](_0x543517,_0x2e7cb8);},'cOtnQ':_0x1fd0a2[_0x4cc652(0x251,'e7W(')],'kGjuD':_0x1fd0a2[_0x4cc652(0x223,'SM05')],'qXxax':function(_0x360757,_0x285fa9){return _0x360757(_0x285fa9);},'gACMJ':function(_0x31b568,_0x388a02){return _0x31b568(_0x388a02);},'gRYPr':function(_0x1ed604,_0x34f509){const _0x4b8a45=_0x4cc652;return _0x1fd0a2[_0x4b8a45(0x18d,'YUJT')](_0x1ed604,_0x34f509);},'Uhkgw':_0x1fd0a2['BAXDc'],'AePvS':_0x1fd0a2[_0x4cc652(0x1c4,'GImO')],'YsPjj':function(_0x41b131){return _0x1fd0a2['SYNey'](_0x41b131);},'nFncC':function(_0x2db71e,_0x53576e){const _0x5c3147=_0x4cc652;return _0x1fd0a2[_0x5c3147(0x1ec,'(*gJ')](_0x2db71e,_0x53576e);}};if(_0x4cc652(0x201,'qM9R')===_0x1fd0a2['OfnZA']){var _0xebef25={'method':_0x1fd0a2['qpHCr'],'url':_0x1fd0a2[_0x4cc652(0x1bb,'a5MK')],'headers':{'Host':_0x1fd0a2[_0x4cc652(0x1cc,'O5g7')],'Connection':_0x1fd0a2[_0x4cc652(0x1d4,'!0JJ')],'Content-Length':'92','Pragma':_0x1fd0a2[_0x4cc652(0x1b0,'I0!@')],'Cache-Control':_0x1fd0a2[_0x4cc652(0x219,'Uv7k')],'accessToken':accessToken,'Origin':_0x1fd0a2['CeCqe'],'User-Agent':_0x4cc652(0x1f2,'GImO'),'Sec-Fetch-Mode':_0x1fd0a2[_0x4cc652(0x1fa,'allO')],'Content-Type':_0x1fd0a2[_0x4cc652(0x1db,'!0JJ')],'Accept':_0x4cc652(0x2b3,'qM9R'),'authorization':authorization,'X-Requested-With':'com.cloudpower.netsale.activity','Sec-Fetch-Site':_0x1fd0a2[_0x4cc652(0x1c1,'Jj8Y')],'Referer':_0x1fd0a2[_0x4cc652(0x289,'Jj8Y')],'Accept-Encoding':_0x1fd0a2[_0x4cc652(0x29f,'SM05')],'Accept-Language':_0x1fd0a2[_0x4cc652(0x196,'Jh9u')]},'data':{'body':{'tId':_0x9ff9bc,'sId':sId}}};debug&&(_0x1fd0a2[_0x4cc652(0x1c3,'TiiI')](log,_0x4cc652(0x299,'qM9R')),_0x1fd0a2[_0x4cc652(0x20e,'2tdI')](log,JSON[_0x4cc652(0x174,'Jh9u')](_0xebef25))),axios[_0x4cc652(0x2bb,'3F!w')](_0xebef25)[_0x4cc652(0x1a5,'D88D')](async function(_0x32a778){const _0x3e7dad=_0x4cc652,_0x2ec3d4={'JSsJh':function(_0x310cbb,_0x227037){return _0x310cbb==_0x227037;},'mEIbh':function(_0x9a463d,_0x166b9f){return _0x19d064['XRPMY'](_0x9a463d,_0x166b9f);}};if('qeTya'===_0x19d064['FPDXN'])_0x41f3f9();else try{if(_0x19d064[_0x3e7dad(0x1f5,'kN@k')](_0x3e7dad(0x244,'kN@k'),_0x19d064[_0x3e7dad(0x2b5,'nCXX')]))data=_0x32a778['data'],debug&&(_0x19d064[_0x3e7dad(0x1ee,'allO')](log,'\x0a\x0a【debug】===============这是\x20返回data=============='),_0x19d064[_0x3e7dad(0x215,'nCXX')](log,_0x32a778[_0x3e7dad(0x1cd,')lgJ')])),_0x19d064['KUCFo'](log,data[_0x3e7dad(0x2a5,'Jj8Y')]);else{_0x210bcc=_0x38e05d[_0x3e7dad(0x230,'m3fN')];_0x251ba1&&(_0x2a585f(_0x3e7dad(0x2b9,'(*gJ')),_0x1debce(_0x30a592['data']));if(_0x2ec3d4[_0x3e7dad(0x1bd,'eZYN')](_0x1c0069[_0x3e7dad(0x1ad,'s5!t')],0x0))_0x334ebc=_0x4c4373['data'][_0x3e7dad(0x2ad,'Jj8Y')],_0x2ec3d4['mEIbh'](_0x20cad6,_0x4dd314);else _0x2ec3d4[_0x3e7dad(0x21f,'wym@')](_0x157de4,_0xd31863);}}catch(_0x47bdfd){if(_0x19d064[_0x3e7dad(0x19a,']FAd')](_0x19d064[_0x3e7dad(0x1d5,'e7W(')],_0x19d064[_0x3e7dad(0x28d,'Jh9u')]))_0x19d064['qXxax'](log,''+data[_0x3e7dad(0x2a4,'allO')]);else try{_0x436853=_0x7febdd[_0x3e7dad(0x273,'D88D')],_0x365dd7&&(_0x1548d4(_0x3e7dad(0x27f,'e7W(')),_0x47cd02(_0x472355['data'])),_0x19d064[_0x3e7dad(0x24c,'qM9R')](_0x490f1a,_0x210459[_0x3e7dad(0x236,'Jh9u')]);}catch(_0x4dd154){_0x19d064[_0x3e7dad(0x20a,'iG@%')](_0x1a68c4,''+_0x57a3c7['message']);}}})[_0x4cc652(0x194,'zl64')](function(_0x48735a){const _0x25ac18=_0x4cc652;_0x19d064[_0x25ac18(0x1dd,'qM9R')]===_0x19d064['AePvS']?(_0x19d064[_0x25ac18(0x211,'Jh9u')](_0x437a9c,_0x25ac18(0x1f0,'wym@')),_0x19d064[_0x25ac18(0x21b,'pF5r')](_0x256ce4,_0x2b6fb0[_0x25ac18(0x283,'zoS3')](_0x5e2994))):console[_0x25ac18(0x193,'2cAl')](_0x48735a);})[_0x4cc652(0x209,'VO]C')](_0x21d66b=>{_0x19d064['YsPjj'](_0x11184a);});}else _0x19d064[_0x4cc652(0x1bf,'Jj8Y')](_0x1370b7,_0x4cc652(0x28e,'AeOU')),_0x99a6be(_0x51cb2b['data']);});}async function pageInitialization1(){const _0x6b24d8=_0x1e1065,_0x5d4272={'OrBoc':function(_0x558a4d,_0xc750c8){return _0x558a4d(_0xc750c8);},'yxvSE':function(_0x1f7b19,_0x5688d8){return _0x1f7b19==_0x5688d8;},'UalaS':function(_0x437c2d,_0x472252){return _0x437c2d!==_0x472252;},'tufLm':_0x6b24d8(0x21c,'#X$v'),'qqWnD':function(_0x578e24,_0x182ee9){return _0x578e24==_0x182ee9;},'qUJgq':'NYGVE','GGdjR':function(_0x44a608,_0x23e694){return _0x44a608===_0x23e694;},'IAQgX':'POST','ZIWRN':'zgrb.epicc.com.cn','uVGyO':_0x6b24d8(0x1f3,'(*gJ'),'PlaJQ':_0x6b24d8(0x239,'GImO'),'nmqHA':_0x6b24d8(0x17b,')wLw'),'BzkVo':'Mozilla/5.0\x20(Linux;\x20Android\x2010;\x20PCAM00\x20Build/QKQ1.190918.001;\x20wv)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Version/4.0\x20Chrome/77.0.3865.92\x20Mobile\x20Safari/537.36\x20PBrowser/3.15.0\x20PiccApp/6.13.2\x20&&webViewInfo=3.15.0&&appInfo=piccApp&&appVersion=6.13.2;webank/h5face;webank/2.0','juHNo':'cors','EHcWL':'application/json','iaRig':_0x6b24d8(0x24f,'huv2'),'PpGcn':'same-origin','aPfFv':'https://zgrb.epicc.com.cn/G-WEB/h5/clockinNew/index.html','hKGPC':'gzip,\x20deflate','IxYyA':'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7'};return new Promise(_0xbdd0c2=>{const _0x42bdfe=_0x6b24d8,_0x36b930={'sesBi':function(_0x227bfe,_0x3b28a0){const _0x109193=_0x1528;return _0x5d4272[_0x109193(0x214,'zl64')](_0x227bfe,_0x3b28a0);},'nTWZP':function(_0x2f7f0d,_0x3ea300){return _0x5d4272['OrBoc'](_0x2f7f0d,_0x3ea300);},'qRpUo':function(_0x36853a,_0x4c5fd){return _0x5d4272['UalaS'](_0x36853a,_0x4c5fd);},'IOUfr':'ZqzRF','swvxy':function(_0x27ebca,_0x1271a0){return _0x27ebca===_0x1271a0;},'ulkWD':_0x5d4272['tufLm'],'eyaZf':function(_0x4fbe75,_0x107fce){return _0x4fbe75(_0x107fce);},'OwVIW':function(_0x33ac59,_0x5a8af5){const _0x2100f6=_0x1528;return _0x5d4272[_0x2100f6(0x296,'D88D')](_0x33ac59,_0x5a8af5);},'wdxzQ':function(_0x506ba3,_0x236684){const _0x3007f9=_0x1528;return _0x5d4272[_0x3007f9(0x1af,'vr!p')](_0x506ba3,_0x236684);},'moyjW':_0x5d4272[_0x42bdfe(0x26c,'vr!p')],'LbWzH':'czPJc','dgVRA':function(_0x348abb,_0x2edcdb){const _0xea619e=_0x42bdfe;return _0x5d4272[_0xea619e(0x1b1,'CKXm')](_0x348abb,_0x2edcdb);}};if(_0x5d4272['GGdjR'](_0x42bdfe(0x1fc,'2cAl'),'EsRXp'))_0x5d4272[_0x42bdfe(0x1be,'Jh9u')](_0x4c61ec,_0x42bdfe(0x20b,'O5g7')+_0x43b930+'，原因：'+_0x140810[_0x42bdfe(0x1c9,'CKXm')]);else{var _0x10862d={'method':_0x5d4272['IAQgX'],'url':_0x42bdfe(0x23c,'e7W('),'headers':{'Host':_0x5d4272[_0x42bdfe(0x232,'XIBT')],'Connection':_0x5d4272[_0x42bdfe(0x17e,'TiiI')],'Content-Length':'2','Pragma':_0x5d4272['PlaJQ'],'Cache-Control':'no-cache','accessToken':accessToken,'Origin':_0x5d4272['nmqHA'],'User-Agent':_0x5d4272[_0x42bdfe(0x22e,'Q19s')],'Sec-Fetch-Mode':_0x5d4272['juHNo'],'Content-Type':_0x5d4272[_0x42bdfe(0x276,'Uv7k')],'Accept':_0x5d4272[_0x42bdfe(0x2b7,'!0JJ')],'authorization':authorization,'X-Requested-With':_0x42bdfe(0x21a,'Uv7k'),'Sec-Fetch-Site':_0x5d4272['PpGcn'],'Referer':_0x5d4272[_0x42bdfe(0x1fe,'CKXm')],'Accept-Encoding':_0x5d4272['hKGPC'],'Accept-Language':_0x5d4272[_0x42bdfe(0x17f,'2cAl')]},'data':'{}'};debug&&(log(_0x42bdfe(0x1f8,'AeOU')),_0x5d4272[_0x42bdfe(0x234,'s5!t')](log,JSON[_0x42bdfe(0x2a9,'qM9R')](_0x10862d))),axios[_0x42bdfe(0x190,'!0JJ')](_0x10862d)[_0x42bdfe(0x18b,')lgJ')](async function(_0x4cfdd0){const _0x3d483c=_0x42bdfe,_0x32acc4={'rcggD':function(_0x58072f,_0x3bff8b){return _0x58072f(_0x3bff8b);},'xqPQk':function(_0x28208e,_0x3cfb2f){const _0x4fb7b8=_0x1528;return _0x36b930[_0x4fb7b8(0x22a,'vr!p')](_0x28208e,_0x3cfb2f);},'uGCIB':function(_0x3aba79,_0x239025){const _0x33a5e4=_0x1528;return _0x36b930[_0x33a5e4(0x1da,'CKXm')](_0x3aba79,_0x239025);}};try{if(_0x36b930['qRpUo'](_0x36b930[_0x3d483c(0x186,'kN@k')],'ZqzRF')){_0x1f4a39=_0x576d0d['data'];_0x5f07ec&&(_0x32acc4[_0x3d483c(0x240,'&N5f')](_0x44697b,_0x3d483c(0x29a,'@OXF')),_0x1c69eb(_0x4bea7e[_0x3d483c(0x250,'e7W(')]));if(_0x32acc4[_0x3d483c(0x169,'I0!@')](_0x3b0628['code'],0x0))_0x32acc4[_0x3d483c(0x173,'2tdI')](_0x5042e0,_0xa14ee9[_0x3d483c(0x275,'m3fN')]);else _0x2df3cb(_0x3a8585['message']);}else{data=_0x4cfdd0[_0x3d483c(0x272,'TP4q')];debug&&(_0x36b930[_0x3d483c(0x178,'@OXF')](_0x36b930[_0x3d483c(0x1e0,'YUJT')],_0x36b930['ulkWD'])?(_0x36b930[_0x3d483c(0x260,'VO]C')](log,'\x0a\x0a【debug】===============这是\x20返回data=============='),log(_0x4cfdd0['data'])):_0x25ea24[_0x3d483c(0x1aa,'YUJT')](_0x33e9ba));if(_0x36b930[_0x3d483c(0x1d7,'TP4q')](data[_0x3d483c(0x287,'q9Nr')],0x0))_0x36b930[_0x3d483c(0x202,'Uv7k')](_0x36b930[_0x3d483c(0x267,'q9Nr')],_0x36b930[_0x3d483c(0x263,'I0!@')])?(temperatureValue=data[_0x3d483c(0x290,'IPi1')]['temperatureValue'],log(temperatureValue)):(_0x85a111(_0x3d483c(0x298,'nCXX')),_0x1edfca(_0x59019d['stringify'](_0x32e841)));else _0x36b930[_0x3d483c(0x1e3,'Jh9u')](log,data);}}catch(_0x9181e6){log(_0x3d483c(0x28c,'Uv7k')+data+_0x3d483c(0x259,'m3fN')+data[_0x3d483c(0x28f,'kN@k')]);}})[_0x42bdfe(0x284,'6hA[')](function(_0x1c6312){const _0x38ee9b=_0x42bdfe;console[_0x38ee9b(0x249,'e7W(')](_0x1c6312);})[_0x42bdfe(0x1d8,'TiiI')](_0x370703=>{_0xbdd0c2();});}});}var version_ = 'jsjiami.com.v7';
async function Envs() {
    if (picchd) {
        if (picchd.indexOf("@") != -1) {
            picchd.split("@").forEach((item) => {

                picchdArr.push(item);
            });
        } else if (picchd.indexOf("\n") != -1) {
            picchd.split("\n").forEach((item) => {
                picchdArr.push(item);
            });
        } else {
            picchdArr.push(picchd);
        }
    } else {
        log(`\n 【${$.name}】：未填写变量 picchd`)
        return;
    }

    return true;
}
function addNotifyStr(str, is_log = true) {
    if (is_log) {
        log(`${str}\n`)
    }
    msg += `${str}\n`
}

// ============================================发送消息============================================ \\
async function SendMsg(message) {
    if (!message)
        return;

    if (Notify > 0) {
        if ($.isNode()) {
            var notify = require('./sendNotify');
            await notify.sendNotify($.name, message);
        } else {
            $.msg(message);
        }
    } else {
        log(message);
    }
}
function Env(t, e) {
    "undefined" != typeof process && JSON.stringify(process.env).indexOf("GITHUB") > -1 && process.exit(0);

    class s {
        constructor(t) {
            this.env = t
        }

        send(t, e = "GET") {
            t = "string" == typeof t ? {
                url: t
            } : t;
            let s = this.get;
            return "POST" === e && (s = this.post), new Promise((e, i) => {
                s.call(this, t, (t, s, r) => {
                    t ? i(t) : e(s)
                })
            })
        }

        get(t) {
            return this.send.call(this.env, t)
        }

        post(t) {
            return this.send.call(this.env, t, "POST")
        }
    }

    return new class {
        constructor(t, e) {
            this.name = t, this.http = new s(this), this.data = null, this.dataFile = "box.dat", this.logs = [], this.isMute = !1, this.isNeedRewrite = !1, this.logSeparator = "\n", this.startTime = (new Date).getTime(), Object.assign(this, e), this.log("", `🔔${this.name}, 开始!`)
        }

        isNode() {
            return "undefined" != typeof module && !!module.exports
        }

        isQuanX() {
            return "undefined" != typeof $task
        }

        isSurge() {
            return "undefined" != typeof $httpClient && "undefined" == typeof $loon
        }

        isLoon() {
            return "undefined" != typeof $loon
        }

        toObj(t, e = null) {
            try {
                return JSON.parse(t)
            } catch {
                return e
            }
        }

        toStr(t, e = null) {
            try {
                return JSON.stringify(t)
            } catch {
                return e
            }
        }

        getjson(t, e) {
            let s = e;
            const i = this.getdata(t);
            if (i) try {
                s = JSON.parse(this.getdata(t))
            } catch {}
            return s
        }

        setjson(t, e) {
            try {
                return this.setdata(JSON.stringify(t), e)
            } catch {
                return !1
            }
        }

        getScript(t) {
            return new Promise(e => {
                this.get({
                    url: t
                }, (t, s, i) => e(i))
            })
        }

        runScript(t, e) {
            return new Promise(s => {
                let i = this.getdata("@chavy_boxjs_userCfgs.httpapi");
                i = i ? i.replace(/\n/g, "").trim() : i;
                let r = this.getdata("@chavy_boxjs_userCfgs.httpapi_timeout");
                r = r ? 1 * r : 20, r = e && e.timeout ? e.timeout : r;
                const [o, h] = i.split("@"), n = {
                    url: `http://${h}/v1/scripting/evaluate`,
                    body: {
                        script_text: t,
                        mock_type: "cron",
                        timeout: r
                    },
                    headers: {
                        "X-Key": o,
                        Accept: "*/*"
                    }
                };
                this.post(n, (t, e, i) => s(i))
            }).catch(t => this.logErr(t))
        }

        loaddata() {
            if (!this.isNode()) return {}; {
                this.fs = this.fs ? this.fs : require("fs"), this.path = this.path ? this.path : require("path");
                const t = this.path.resolve(this.dataFile),
                    e = this.path.resolve(process.cwd(), this.dataFile),
                    s = this.fs.existsSync(t),
                    i = !s && this.fs.existsSync(e);
                if (!s && !i) return {}; {
                    const i = s ? t : e;
                    try {
                        return JSON.parse(this.fs.readFileSync(i))
                    } catch (t) {
                        return {}
                    }
                }
            }
        }

        writedata() {
            if (this.isNode()) {
                this.fs = this.fs ? this.fs : require("fs"), this.path = this.path ? this.path : require("path");
                const t = this.path.resolve(this.dataFile),
                    e = this.path.resolve(process.cwd(), this.dataFile),
                    s = this.fs.existsSync(t),
                    i = !s && this.fs.existsSync(e),
                    r = JSON.stringify(this.data);
                s ? this.fs.writeFileSync(t, r) : i ? this.fs.writeFileSync(e, r) : this.fs.writeFileSync(t, r)
            }
        }

        lodash_get(t, e, s) {
            const i = e.replace(/\[(\d+)\]/g, ".$1").split(".");
            let r = t;
            for (const t of i)
                if (r = Object(r)[t], void 0 === r) return s;
            return r
        }

        lodash_set(t, e, s) {
            return Object(t) !== t ? t : (Array.isArray(e) || (e = e.toString().match(/[^.[\]]+/g) || []), e.slice(0, -1).reduce((t, s, i) => Object(t[s]) === t[s] ? t[s] : t[s] = Math.abs(e[i + 1]) >> 0 == +e[i + 1] ? [] : {}, t)[e[e.length - 1]] = s, t)
        }

        getdata(t) {
            let e = this.getval(t);
            if (/^@/.test(t)) {
                const [, s, i] = /^@(.*?)\.(.*?)$/.exec(t), r = s ? this.getval(s) : "";
                if (r) try {
                    const t = JSON.parse(r);
                    e = t ? this.lodash_get(t, i, "") : e
                } catch (t) {
                    e = ""
                }
            }
            return e
        }

        setdata(t, e) {
            let s = !1;
            if (/^@/.test(e)) {
                const [, i, r] = /^@(.*?)\.(.*?)$/.exec(e), o = this.getval(i),
                    h = i ? "null" === o ? null : o || "{}" : "{}";
                try {
                    const e = JSON.parse(h);
                    this.lodash_set(e, r, t), s = this.setval(JSON.stringify(e), i)
                } catch (e) {
                    const o = {};
                    this.lodash_set(o, r, t), s = this.setval(JSON.stringify(o), i)
                }
            } else s = this.setval(t, e);
            return s
        }

        getval(t) {
            return this.isSurge() || this.isLoon() ? $persistentStore.read(t) : this.isQuanX() ? $prefs.valueForKey(t) : this.isNode() ? (this.data = this.loaddata(), this.data[t]) : this.data && this.data[t] || null
        }

        setval(t, e) {
            return this.isSurge() || this.isLoon() ? $persistentStore.write(t, e) : this.isQuanX() ? $prefs.setValueForKey(t, e) : this.isNode() ? (this.data = this.loaddata(), this.data[e] = t, this.writedata(), !0) : this.data && this.data[e] || null
        }

        initGotEnv(t) {
            this.got = this.got ? this.got : require("got"), this.cktough = this.cktough ? this.cktough : require("tough-cookie"), this.ckjar = this.ckjar ? this.ckjar : new this.cktough.CookieJar, t && (t.headers = t.headers ? t.headers : {}, void 0 === t.headers.Cookie && void 0 === t.cookieJar && (t.cookieJar = this.ckjar))
        }

        get(t, e = (() => {})) {
            t.headers && (delete t.headers["Content-Type"], delete t.headers["Content-Length"]), this.isSurge() || this.isLoon() ? (this.isSurge() && this.isNeedRewrite && (t.headers = t.headers || {}, Object.assign(t.headers, {
                "X-Surge-Skip-Scripting": !1
            })), $httpClient.get(t, (t, s, i) => {
                !t && s && (s.body = i, s.statusCode = s.status), e(t, s, i)
            })) : this.isQuanX() ? (this.isNeedRewrite && (t.opts = t.opts || {}, Object.assign(t.opts, {
                hints: !1
            })), $task.fetch(t).then(t => {
                const {
                    statusCode: s,
                    statusCode: i,
                    headers: r,
                    body: o
                } = t;
                e(null, {
                    status: s,
                    statusCode: i,
                    headers: r,
                    body: o
                }, o)
            }, t => e(t))) : this.isNode() && (this.initGotEnv(t), this.got(t).on("redirect", (t, e) => {
                try {
                    if (t.headers["set-cookie"]) {
                        const s = t.headers["set-cookie"].map(this.cktough.Cookie.parse).toString();
                        s && this.ckjar.setCookieSync(s, null), e.cookieJar = this.ckjar
                    }
                } catch (t) {
                    this.logErr(t)
                }
            }).then(t => {
                const {
                    statusCode: s,
                    statusCode: i,
                    headers: r,
                    body: o
                } = t;
                e(null, {
                    status: s,
                    statusCode: i,
                    headers: r,
                    body: o
                }, o)
            }, t => {
                const {
                    message: s,
                    response: i
                } = t;
                e(s, i, i && i.body)
            }))
        }

        post(t, e = (() => {})) {
            if (t.body && t.headers && !t.headers["Content-Type"] && (t.headers["Content-Type"] = "application/x-www-form-urlencoded"), t.headers && delete t.headers["Content-Length"], this.isSurge() || this.isLoon()) this.isSurge() && this.isNeedRewrite && (t.headers = t.headers || {}, Object.assign(t.headers, {
                "X-Surge-Skip-Scripting": !1
            })), $httpClient.post(t, (t, s, i) => {
                !t && s && (s.body = i, s.statusCode = s.status), e(t, s, i)
            });
            else if (this.isQuanX()) t.method = "POST", this.isNeedRewrite && (t.opts = t.opts || {}, Object.assign(t.opts, {
                hints: !1
            })), $task.fetch(t).then(t => {
                const {
                    statusCode: s,
                    statusCode: i,
                    headers: r,
                    body: o
                } = t;
                e(null, {
                    status: s,
                    statusCode: i,
                    headers: r,
                    body: o
                }, o)
            }, t => e(t));
            else if (this.isNode()) {
                this.initGotEnv(t);
                const {
                    url: s,
                    ...i
                } = t;
                this.got.post(s, i).then(t => {
                    const {
                        statusCode: s,
                        statusCode: i,
                        headers: r,
                        body: o
                    } = t;
                    e(null, {
                        status: s,
                        statusCode: i,
                        headers: r,
                        body: o
                    }, o)
                }, t => {
                    const {
                        message: s,
                        response: i
                    } = t;
                    e(s, i, i && i.body)
                })
            }
        }

        time(t, e = null) {
            const s = e ? new Date(e) : new Date;
            let i = {
                "M+": s.getMonth() + 1,
                "d+": s.getDate(),
                "H+": s.getHours(),
                "m+": s.getMinutes(),
                "s+": s.getSeconds(),
                "q+": Math.floor((s.getMonth() + 3) / 3),
                S: s.getMilliseconds()
            };
            /(y+)/.test(t) && (t = t.replace(RegExp.$1, (s.getFullYear() + "").substr(4 - RegExp.$1.length)));
            for (let e in i) new RegExp("(" + e + ")").test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? i[e] : ("00" + i[e]).substr(("" + i[e]).length)));
            return t
        }

        msg(e = t, s = "", i = "", r) {
            const o = t => {
                if (!t) return t;
                if ("string" == typeof t) return this.isLoon() ? t : this.isQuanX() ? {
                    "open-url": t
                } : this.isSurge() ? {
                    url: t
                } : void 0;
                if ("object" == typeof t) {
                    if (this.isLoon()) {
                        let e = t.openUrl || t.url || t["open-url"],
                            s = t.mediaUrl || t["media-url"];
                        return {
                            openUrl: e,
                            mediaUrl: s
                        }
                    }
                    if (this.isQuanX()) {
                        let e = t["open-url"] || t.url || t.openUrl,
                            s = t["media-url"] || t.mediaUrl;
                        return {
                            "open-url": e,
                            "media-url": s
                        }
                    }
                    if (this.isSurge()) {
                        let e = t.url || t.openUrl || t["open-url"];
                        return {
                            url: e
                        }
                    }
                }
            };
            if (this.isMute || (this.isSurge() || this.isLoon() ? $notification.post(e, s, i, o(r)) : this.isQuanX() && $notify(e, s, i, o(r))), !this.isMuteLog) {
                let t = ["", "==============📣系统通知📣=============="];
                t.push(e), s && t.push(s), i && t.push(i), console.log(t.join("\n")), this.logs = this.logs.concat(t)
            }
        }

        log(...t) {
            t.length > 0 && (this.logs = [...this.logs, ...t]), console.log(t.join(this.logSeparator))
        }

        logErr(t, e) {
            const s = !this.isSurge() && !this.isQuanX() && !this.isLoon();
            s ? this.log("", `❗️${this.name}, 错误!`, t.stack) : this.log("", `❗️${this.name}, 错误!`, t)
        }

        wait(t) {
            return new Promise(e => setTimeout(e, t))
        }

        done(t = {}) {
            const e = (new Date).getTime(),
                s = (e - this.startTime) / 1e3;
            this.log("", `🔔${this.name}, 结束! 🕛 ${s} 秒`), this.log(), (this.isSurge() || this.isQuanX() || this.isLoon()) && $done(t)
        }
    }(t, e)
}